import { Router, type IRouter } from "express";
import { eq, desc, max, count } from "drizzle-orm";
import { db, quizReportsTable } from "@workspace/db";
import { SubmitQuizReportBody } from "@workspace/api-zod";
import type { QuizReport } from "@workspace/db";

const router: IRouter = Router();

router.post("/quiz-reports", async (req, res): Promise<void> => {
  const parsed = SubmitQuizReportBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [inserted] = await db
    .insert(quizReportsTable)
    .values(parsed.data)
    .returning();
  res.status(201).json({
    ...inserted,
    createdAt: inserted.createdAt.toISOString(),
  });
});

router.get("/quiz-reports/leaderboard", async (req, res): Promise<void> => {
  const quizId = req.query.quizId as string;
  if (!quizId) {
    res.status(400).json({ error: "quizId is required" });
    return;
  }
  const rows = await db
    .select({
      userName: quizReportsTable.userName,
      bestScore: max(quizReportsTable.score),
      bestPct: max(quizReportsTable.pct),
      correct: max(quizReportsTable.correct),
      total: max(quizReportsTable.total),
      attempts: count(),
    })
    .from(quizReportsTable)
    .where(eq(quizReportsTable.quizId, quizId))
    .groupBy(quizReportsTable.userName)
    .orderBy(desc(max(quizReportsTable.score)));

  res.json(
    rows.map((r) => ({
      userName: r.userName,
      bestScore: r.bestScore ?? 0,
      bestPct: r.bestPct ?? 0,
      correct: r.correct ?? 0,
      total: r.total ?? 0,
      attempts: r.attempts,
    }))
  );
});

router.get("/quiz-reports/users", async (req, res): Promise<void> => {
  const rows = await db
    .select({ userName: quizReportsTable.userName, attempts: count() })
    .from(quizReportsTable)
    .groupBy(quizReportsTable.userName)
    .orderBy(quizReportsTable.userName);
  res.json(rows.map((r) => ({ userName: r.userName, attempts: r.attempts })));
});

router.get("/quiz-reports/analytics", async (req, res): Promise<void> => {
  const userName = req.query.userName as string;
  if (!userName) {
    res.status(400).json({ error: "userName is required" });
    return;
  }
  const reports = await db
    .select()
    .from(quizReportsTable)
    .where(eq(quizReportsTable.userName, userName));
  res.json(buildAnalytics(userName, reports));
});

router.get("/quiz-reports/compare", async (req, res): Promise<void> => {
  const user1 = req.query.user1 as string;
  const user2 = req.query.user2 as string;
  if (!user1 || !user2) {
    res.status(400).json({ error: "user1 and user2 are required" });
    return;
  }
  const [r1, r2] = await Promise.all([
    db.select().from(quizReportsTable).where(eq(quizReportsTable.userName, user1)),
    db.select().from(quizReportsTable).where(eq(quizReportsTable.userName, user2)),
  ]);
  res.json([buildAnalytics(user1, r1), buildAnalytics(user2, r2)]);
});

function buildAnalytics(userName: string, reports: QuizReport[]) {
  if (reports.length === 0) {
    return { userName, totalAttempts: 0, avgPct: 0, bySubject: [], bySem: [], byExamType: [] };
  }
  const totalAttempts = reports.length;
  const avgPct = reports.reduce((s, r) => s + r.pct, 0) / totalAttempts;

  function group(key: keyof QuizReport) {
    const map: Record<string, { sum: number; cnt: number }> = {};
    reports.forEach((r) => {
      const k = String(r[key]);
      if (!map[k]) map[k] = { sum: 0, cnt: 0 };
      map[k].sum += r.pct;
      map[k].cnt++;
    });
    return map;
  }

  const bySubjectMap = group("subject");
  const bySemMap = group("sem");
  const byExamTypeMap = group("examType");

  return {
    userName,
    totalAttempts,
    avgPct: Math.round(avgPct * 10) / 10,
    bySubject: Object.entries(bySubjectMap).map(([subject, { sum, cnt }]) => ({
      subject,
      avgPct: Math.round((sum / cnt) * 10) / 10,
      attempts: cnt,
    })),
    bySem: Object.entries(bySemMap).map(([sem, { sum, cnt }]) => ({
      sem: Number(sem),
      avgPct: Math.round((sum / cnt) * 10) / 10,
      attempts: cnt,
    })),
    byExamType: Object.entries(byExamTypeMap).map(([examType, { sum, cnt }]) => ({
      examType,
      avgPct: Math.round((sum / cnt) * 10) / 10,
      attempts: cnt,
    })),
  };
}

export default router;
