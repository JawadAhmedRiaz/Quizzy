import { Router, type IRouter } from "express";
import healthRouter from "./health";
import leaderboardRouter from "./leaderboard";
import authRouter from "./auth";
import quizReportsRouter from "./quiz-reports";

const router: IRouter = Router();

router.use(healthRouter);
router.use(leaderboardRouter);
router.use(authRouter);
router.use(quizReportsRouter);

export default router;
