import type { Question } from "./questions";

export const ENTREPRENEURSHIP_Q: Question[] = [
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "Entrepreneurship is best described as:",
    "o": [
      "The management of an existing large corporation",
      "The art of starting a business, offering creative products, processes, or services",
      "The process of acquiring a franchise from an established brand",
      "The study of economic theories in market systems"
    ],
    "a": 1,
    "e": "Correct answer: The art of starting a business, offering creative products, processes, or services. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "Which of the following best defines an entrepreneur?",
    "o": [
      "A government official who regulates markets",
      "An employee who manages a department within a corporation",
      "A creator or designer who introduces new ideas, products, or business processes",
      "A financier who lends money to businesses"
    ],
    "a": 2,
    "e": "Correct answer: A creator or designer who introduces new ideas, products, or business processes. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "According to the material, what is the most important factor for an entrepreneur's performance?",
    "o": [
      "Capital investment",
      "Motivation",
      "Political connections",
      "Geographic location"
    ],
    "a": 1,
    "e": "Correct answer: Motivation. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "The word \"motivation\" is derived from the word:",
    "o": [
      "Moment",
      "Momentum",
      "Motive",
      "Motor"
    ],
    "a": 2,
    "e": "Correct answer: Motive. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "Which of the following is NOT one of the reasons why motivation is required for entrepreneurs?",
    "o": [
      "To face tough competition",
      "To create public demand",
      "To avoid paying taxes",
      "To enhance creativity"
    ],
    "a": 2,
    "e": "Correct answer: To avoid paying taxes. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "The 6Cs that motivate entrepreneurs to start their own business include all of the following EXCEPT:",
    "o": [
      "Change",
      "Challenge",
      "Compliance",
      "Cash"
    ],
    "a": 2,
    "e": "Correct answer: Compliance. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "An entrepreneur who is motivated by \"Control\" is primarily driven by:",
    "o": [
      "Earning the most profit possible",
      "Wanting to be their own boss and shape the company's direction",
      "Exploring new scientific discoveries",
      "Bringing about social change"
    ],
    "a": 1,
    "e": "Correct answer: Wanting to be their own boss and shape the company's direction. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "The \"Curiosity\" factor of entrepreneurial motivation is most similar to:",
    "o": [
      "A lawyer arguing a case",
      "A scientist trying to prove a theorem",
      "An accountant balancing books",
      "A politician seeking votes"
    ],
    "a": 1,
    "e": "Correct answer: A scientist trying to prove a theorem. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "According to the material, which motivational factor do many non-entrepreneurs wrongly assume comes first for entrepreneurs?",
    "o": [
      "Change",
      "Creativity",
      "Cash",
      "Challenge"
    ],
    "a": 2,
    "e": "Correct answer: Cash. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "Which of the following is a result of motivation in entrepreneurship?",
    "o": [
      "Decreased industrialization",
      "Reduced employment opportunities",
      "Economic growth and new job creation",
      "Increased dependence on government welfare"
    ],
    "a": 2,
    "e": "Correct answer: Economic growth and new job creation. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "An entrepreneur is considered which of the following?",
    "o": [
      "Only a borrower of capital",
      "Innovator, creator, borrower, and purchaser",
      "Only a seller of goods",
      "Only an employer of labor"
    ],
    "a": 1,
    "e": "Correct answer: Innovator, creator, borrower, and purchaser. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "Successful entrepreneurship requires all of the following EXCEPT:",
    "o": [
      "Determination",
      "Discipline",
      "Guarantee of success",
      "Planning skills"
    ],
    "a": 2,
    "e": "Correct answer: Guarantee of success. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "\"Heavy industrialization\" as a result of entrepreneurial motivation is exemplified by:",
    "o": [
      "Small family businesses",
      "Companies like TISCO and TELCO",
      "Government-run public enterprises",
      "Informal sector traders"
    ],
    "a": 1,
    "e": "Correct answer: Companies like TISCO and TELCO. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "The entrepreneurial drive is best described as:",
    "o": [
      "A business loan repayment plan",
      "The inbuilt encouragement to make something happen and not give up in the face of failure",
      "A motivational speech delivered by a manager",
      "A formal business contract"
    ],
    "a": 1,
    "e": "Correct answer: The inbuilt encouragement to make something happen and not give up in the face of failure. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "Which of the following famous names is listed as an entrepreneur in the material?",
    "o": [
      "Warren Buffett",
      "Azim Premji",
      "Bill Clinton",
      "Jack Ma"
    ],
    "a": 1,
    "e": "Correct answer: Azim Premji. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "An entrepreneur's performance is dependent on:",
    "o": [
      "Luck and timing alone",
      "Ability (education, experience, skill) and willingness (motivation level)",
      "Government subsidies and grants",
      "Number of employees in the company"
    ],
    "a": 1,
    "e": "Correct answer: Ability (education, experience, skill) and willingness (motivation level). Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "Which of the following correctly describes the \"Change\" motivation among the 6Cs?",
    "o": [
      "Entrepreneurs want to maintain the status quo",
      "Entrepreneurs want to disrupt the status quo and be bearers of change",
      "Entrepreneurs avoid change to ensure business stability",
      "Entrepreneurs value change only when it is profitable"
    ],
    "a": 1,
    "e": "Correct answer: Entrepreneurs want to disrupt the status quo and be bearers of change. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "Political economists regard which qualities as essential for an entrepreneur?",
    "o": [
      "Physical strength and endurance",
      "Leadership, management ability, and team-building skills",
      "Political influence and legal expertise",
      "Scientific knowledge and research skills"
    ],
    "a": 1,
    "e": "Correct answer: Leadership, management ability, and team-building skills. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Entrepreneurship — Fundamentals & Motivation",
    "q": "\"Proper social benefit\" as a result of entrepreneurship includes:",
    "o": [
      "Reduction in business competition",
      "Construction of roads, schools, hospitals, and colleges",
      "Elimination of government services",
      "Restriction of trade"
    ],
    "a": 1,
    "e": "Correct answer: Construction of roads, schools, hospitals, and colleges. Review: Entrepreneurship — Fundamentals & Motivation."
  },
  {
    "c": "Enterprise & Society",
    "q": "The \"Creativity\" motivation for entrepreneurs involves:",
    "o": [
      "Copying existing products from competitors",
      "Testing new designs, launching new schemes, and creating inventive items",
      "Reducing costs by eliminating innovation",
      "Avoiding risk by sticking to proven methods"
    ],
    "a": 1,
    "e": "Correct answer: Testing new designs, launching new schemes, and creating inventive items. Review: Enterprise & Society."
  },
  {
    "c": "Enterprise & Society",
    "q": "Entrepreneurs are not always motivated by profit but regard it as:",
    "o": [
      "The only measure of success",
      "A standard for measuring achievement or success",
      "An obstacle to growth",
      "A tax burden"
    ],
    "a": 1,
    "e": "Correct answer: A standard for measuring achievement or success. Review: Enterprise & Society."
  },
  {
    "c": "Enterprise & Society",
    "q": "Which factor contributing to entrepreneurial achievement involves convincing others to trust you by first trusting yourself?",
    "o": [
      "Experience",
      "Market share",
      "Self-confidence",
      "Brand"
    ],
    "a": 2,
    "e": "Correct answer: Self-confidence. Review: Enterprise & Society."
  },
  {
    "c": "Enterprise & Society",
    "q": "An enterprise is described as:",
    "o": [
      "An independent unit completely separate from society",
      "A portion of society that shares a close bond with it",
      "A purely economic entity with no social dimension",
      "A government institution"
    ],
    "a": 1,
    "e": "Correct answer: A portion of society that shares a close bond with it. Review: Enterprise & Society."
  },
  {
    "c": "Enterprise & Society",
    "q": "Which of the following is NOT listed as a factor of entrepreneurial achievement?",
    "o": [
      "Self-confidence",
      "Experience",
      "Political connections",
      "Brand"
    ],
    "a": 2,
    "e": "Correct answer: Political connections. Review: Enterprise & Society."
  },
  {
    "c": "Enterprise & Society",
    "q": "Why do people start businesses? Which of the following is NOT a listed reason?",
    "o": [
      "To be their own boss",
      "To leave behind a legacy",
      "To avoid paying income tax",
      "To prove self-competence and make an impact on society"
    ],
    "a": 2,
    "e": "Correct answer: To avoid paying income tax. Review: Enterprise & Society."
  },
  {
    "c": "Enterprise & Society",
    "q": "What does the \"10 Steps to Start a Business\" framework begin with?",
    "o": [
      "Obtaining business licenses",
      "Writing a business plan",
      "Getting a tax identification number",
      "Registering with state tax authorities"
    ],
    "a": 1,
    "e": "Correct answer: Writing a business plan. Review: Enterprise & Society."
  },
  {
    "c": "Enterprise & Society",
    "q": "Which step involves deciding whether the business will be a sole proprietorship, partnership, LLC, or corporation?",
    "o": [
      "Writing a business plan",
      "Registering a business name",
      "Determining the legal structure of the business",
      "Getting a tax identification number"
    ],
    "a": 2,
    "e": "Correct answer: Determining the legal structure of the business. Review: Enterprise & Society."
  },
  {
    "c": "Enterprise & Society",
    "q": "Entrepreneurs greatly value:",
    "o": [
      "Dependence on others",
      "Self-reliance and distinction through excellence",
      "Risk avoidance at all costs",
      "Short-term profit maximization only"
    ],
    "a": 1,
    "e": "Correct answer: Self-reliance and distinction through excellence. Review: Enterprise & Society."
  },
  {
    "c": "Enterprise & Society",
    "q": "Entrepreneurs always favor challenges of:",
    "o": [
      "Extremely high risk",
      "Zero risk",
      "Medium risk — neither too easy nor ruinous",
      "Only government-backed ventures"
    ],
    "a": 2,
    "e": "Correct answer: Medium risk — neither too easy nor ruinous. Review: Enterprise & Society."
  },
  {
    "c": "Qualities & Skills of an Entrepreneur",
    "q": "Consumer relations, social support, and government support are described as:",
    "o": [
      "Obstacles to entrepreneurial achievement",
      "Additional factors contributing to entrepreneurial achievement",
      "Irrelevant to business success",
      "Factors that hinder market competition"
    ],
    "a": 1,
    "e": "Correct answer: Additional factors contributing to entrepreneurial achievement. Review: Qualities & Skills of an Entrepreneur."
  },
  {
    "c": "Qualities & Skills of an Entrepreneur",
    "q": "Which quality of an entrepreneur refers to the ability to see things from different points of view?",
    "o": [
      "Patience",
      "Visualization",
      "Emotional tolerance",
      "Technical skill"
    ],
    "a": 1,
    "e": "Correct answer: Visualization. Review: Qualities & Skills of an Entrepreneur."
  },
  {
    "c": "Qualities & Skills of an Entrepreneur",
    "q": "\"Emotional tolerance\" in an entrepreneur is defined as:",
    "o": [
      "Being emotionally detached from all decisions",
      "The ability to balance professional and personal life without mixing them",
      "Suppressing all emotions in the workplace",
      "Reacting emotionally to business challenges"
    ],
    "a": 1,
    "e": "Correct answer: The ability to balance professional and personal life without mixing them. Review: Qualities & Skills of an Entrepreneur."
  },
  {
    "c": "Qualities & Skills of an Entrepreneur",
    "q": "Which entrepreneurial skill involves prioritizing tasks between extremely urgent ones and those that can wait?",
    "o": [
      "Delegating tasks",
      "Visualizing success",
      "Effective time management",
      "Conflict resolution"
    ],
    "a": 2,
    "e": "Correct answer: Effective time management. Review: Qualities & Skills of an Entrepreneur."
  },
  {
    "c": "Qualities & Skills of an Entrepreneur",
    "q": "An entrepreneur who confidently assigns work to experienced team members is demonstrating:",
    "o": [
      "Lack of control",
      "Confidence to delegate tasks",
      "Poor leadership",
      "Risk aversion"
    ],
    "a": 1,
    "e": "Correct answer: Confidence to delegate tasks. Review: Qualities & Skills of an Entrepreneur."
  },
  {
    "c": "Qualities & Skills of an Entrepreneur",
    "q": "\"Seeking help when needed\" is classified as which type of entrepreneurial attribute?",
    "o": [
      "A weakness that must be hidden",
      "An important skill that also strengthens internal communication",
      "An indication of business failure",
      "Relevant only to large corporations"
    ],
    "a": 1,
    "e": "Correct answer: An important skill that also strengthens internal communication. Review: Qualities & Skills of an Entrepreneur."
  },
  {
    "c": "Qualities & Skills of an Entrepreneur",
    "q": "Which of the following is listed as a quality of an entrepreneur?",
    "o": [
      "Avoiding competition at all costs",
      "Conflict resolution skill",
      "Dependence on government support",
      "Fear of taking risks"
    ],
    "a": 1,
    "e": "Correct answer: Conflict resolution skill. Review: Qualities & Skills of an Entrepreneur."
  },
  {
    "c": "Qualities & Skills of an Entrepreneur",
    "q": "\"Reality-oriented\" as a quality of an entrepreneur means:",
    "o": [
      "Being overly optimistic regardless of facts",
      "Being practical and having rational thinking",
      "Relying on intuition alone",
      "Ignoring market data"
    ],
    "a": 1,
    "e": "Correct answer: Being practical and having rational thinking. Review: Qualities & Skills of an Entrepreneur."
  },
  {
    "c": "Qualities & Skills of an Entrepreneur",
    "q": "Which skill involves an entrepreneur being able to manage different people such as clients, employees, co-workers, and competitors?",
    "o": [
      "Technical skill",
      "Managerial skill",
      "Organizing skill",
      "Conflict resolution skill"
    ],
    "a": 1,
    "e": "Correct answer: Managerial skill. Review: Qualities & Skills of an Entrepreneur."
  },
  {
    "c": "Qualities & Skills of an Entrepreneur",
    "q": "The \"Giving Back\" principle in entrepreneurship suggests that:",
    "o": [
      "Entrepreneurs should give back profits to investors only",
      "Successful entrepreneurs should contribute to society and appreciate their achievements",
      "Business owners must donate all profits to charity",
      "Entrepreneurs should avoid personal wealth accumulation"
    ],
    "a": 1,
    "e": "Correct answer: Successful entrepreneurs should contribute to society and appreciate their achievements. Review: Qualities & Skills of an Entrepreneur."
  },
  {
    "c": "Qualities & Skills of an Entrepreneur",
    "q": "Which of the following correctly pairs a quality with its description?",
    "o": [
      "Patience — the ability to lead and motivate others",
      "Risk-taking ability — business is about experimenting and taking risks",
      "Intelligence — ability to resolve disputes",
      "Technical skill — balancing professional and personal life"
    ],
    "a": 1,
    "e": "Correct answer: Risk-taking ability — business is about experimenting and taking risks. Review: Qualities & Skills of an Entrepreneur."
  },
  {
    "c": "Qualities & Skills of an Entrepreneur",
    "q": "\"High motivation\" as a quality means entrepreneurs should:",
    "o": [
      "Be self-motivated only",
      "Be able to encourage everyone around them to give their best",
      "Rely on external incentives only",
      "Avoid motivating employees to prevent dependency"
    ],
    "a": 1,
    "e": "Correct answer: Be able to encourage everyone around them to give their best. Review: Qualities & Skills of an Entrepreneur."
  },
  {
    "c": "Qualities & Skills of an Entrepreneur",
    "q": "Proper listening and communicating is important because poor communication leads to:",
    "o": [
      "Higher profits",
      "Better time management",
      "Miscommunication and wasted time",
      "Stronger team cohesion"
    ],
    "a": 2,
    "e": "Correct answer: Miscommunication and wasted time. Review: Qualities & Skills of an Entrepreneur."
  },
  {
    "c": "Qualities & Skills of an Entrepreneur",
    "q": "Organizing skill for an entrepreneur means:",
    "o": [
      "Avoiding systematic approaches",
      "Being highly organized and maintaining everything in a proper format",
      "Delegating all organizational tasks to staff",
      "Using informal systems for managing business operations"
    ],
    "a": 1,
    "e": "Correct answer: Being highly organized and maintaining everything in a proper format. Review: Qualities & Skills of an Entrepreneur."
  },
  {
    "c": "Qualities & Skills of an Entrepreneur",
    "q": "\"Visualizing Aim and Success\" as an entrepreneurial skill requires entrepreneurs to:",
    "o": [
      "Only visualize the end result, not the steps",
      "Visualize their goals and every step needed to achieve them",
      "Avoid thinking about the future to prevent anxiety",
      "Only focus on day-to-day operations"
    ],
    "a": 1,
    "e": "Correct answer: Visualize their goals and every step needed to achieve them. Review: Qualities & Skills of an Entrepreneur."
  },
  {
    "c": "Mind vs. Money & Determinants of Success/Failure",
    "q": "Which of the following is NOT listed as an essential quality of an entrepreneur?",
    "o": [
      "Leadership quality",
      "Decision-making ability",
      "Physical attractiveness",
      "Patience"
    ],
    "a": 2,
    "e": "Correct answer: Physical attractiveness. Review: Mind vs. Money & Determinants of Success/Failure."
  },
  {
    "c": "Mind vs. Money & Determinants of Success/Failure",
    "q": "For established entrepreneurs, which is considered more important?",
    "o": [
      "Money over mind",
      "Mind over money, as they are already in expansion stage",
      "Neither mind nor money",
      "Government policy over both"
    ],
    "a": 1,
    "e": "Correct answer: Mind over money, as they are already in expansion stage. Review: Mind vs. Money & Determinants of Success/Failure."
  },
  {
    "c": "Mind vs. Money & Determinants of Success/Failure",
    "q": "For new entrepreneurs, which is preferred?",
    "o": [
      "Mind over money",
      "Government grants over both",
      "Money over mind, as they want to settle first",
      "Networking over capital"
    ],
    "a": 2,
    "e": "Correct answer: Money over mind, as they want to settle first. Review: Mind vs. Money & Determinants of Success/Failure."
  },
  {
    "c": "Mind vs. Money & Determinants of Success/Failure",
    "q": "Money transforms ideas into:",
    "o": [
      "Further ideas",
      "Reality",
      "Government policies",
      "Academic theories"
    ],
    "a": 1,
    "e": "Correct answer: Reality. Review: Mind vs. Money & Determinants of Success/Failure."
  },
  {
    "c": "Mind vs. Money & Determinants of Success/Failure",
    "q": "According to the material, what does \"mind\" represent in the context of entrepreneurship?",
    "o": [
      "The physical workspace",
      "The route of creative ideas leading to innovation",
      "The financial capital available",
      "The management hierarchy"
    ],
    "a": 1,
    "e": "Correct answer: The route of creative ideas leading to innovation. Review: Mind vs. Money & Determinants of Success/Failure."
  },
  {
    "c": "Mind vs. Money & Determinants of Success/Failure",
    "q": "Internal factors for success include:",
    "o": [
      "Shortage of raw materials",
      "High market competition",
      "Efficient management and effective marketing",
      "Negative government policies"
    ],
    "a": 2,
    "e": "Correct answer: Efficient management and effective marketing. Review: Mind vs. Money & Determinants of Success/Failure."
  },
  {
    "c": "Mind vs. Money & Determinants of Success/Failure",
    "q": "Which of the following is an EXTERNAL factor for success?",
    "o": [
      "Good reputation of the firm",
      "Low cost production",
      "High demand in the market",
      "Dedicated manpower"
    ],
    "a": 2,
    "e": "Correct answer: High demand in the market. Review: Mind vs. Money & Determinants of Success/Failure."
  },
  {
    "c": "Mind vs. Money & Determinants of Success/Failure",
    "q": "Which of the following is an INTERNAL factor for failure?",
    "o": [
      "Shortage of power",
      "High competition",
      "Poor financing and poor leadership",
      "Change in technology (externally imposed)"
    ],
    "a": 2,
    "e": "Correct answer: Poor financing and poor leadership. Review: Mind vs. Money & Determinants of Success/Failure."
  },
  {
    "c": "Mind vs. Money & Determinants of Success/Failure",
    "q": "External factors for failure include:",
    "o": [
      "Ineffective management",
      "Old technology within the firm",
      "Shortage of raw material and shortage of manpower",
      "Poor internal leadership"
    ],
    "a": 2,
    "e": "Correct answer: Shortage of raw material and shortage of manpower. Review: Mind vs. Money & Determinants of Success/Failure."
  },
  {
    "c": "Mind vs. Money & Determinants of Success/Failure",
    "q": "In entrepreneurship, failure is viewed as:",
    "o": [
      "A permanent ending",
      "A disgrace that ends careers",
      "A positive experience — a challenge and an opportunity for growth",
      "Irrelevant to the entrepreneurial journey"
    ],
    "a": 2,
    "e": "Correct answer: A positive experience — a challenge and an opportunity for growth. Review: Mind vs. Money & Determinants of Success/Failure."
  },
  {
    "c": "Mind vs. Money & Determinants of Success/Failure",
    "q": "Environmental dynamics in business refer to:",
    "o": [
      "Environmental pollution caused by industries",
      "The dynamic nature of the business environment that changes due to different factors and creates new challenges",
      "The physical environment of the factory",
      "Government environmental regulations"
    ],
    "a": 1,
    "e": "Correct answer: The dynamic nature of the business environment that changes due to different factors and creates new challenges. Review: Mind vs. Money & Determinants of Success/Failure."
  },
  {
    "c": "Mind vs. Money & Determinants of Success/Failure",
    "q": "Which of the following best describes the relationship between mind and money?",
    "o": [
      "Money is completely independent of the mind",
      "Mind affects the firm's activities; money affects economic activities — both are vital",
      "Only money matters in business decisions",
      "Mind replaces money in established businesses"
    ],
    "a": 1,
    "e": "Correct answer: Mind affects the firm's activities; money affects economic activities — both are vital. Review: Mind vs. Money & Determinants of Success/Failure."
  },
  {
    "c": "Entrepreneurial Process",
    "q": "\"An idea shows the mission and vision whereas money shows the way to achieve that mission and vision\" is a concept from which topic?",
    "o": [
      "Industrial Policy",
      "International Business",
      "Mind vs. Money",
      "Product Launch"
    ],
    "a": 2,
    "e": "Correct answer: Mind vs. Money. Review: Entrepreneurial Process."
  },
  {
    "c": "Entrepreneurial Process",
    "q": "The first stage in the entrepreneurial process is:",
    "o": [
      "Decision-making steps",
      "Preliminary steps",
      "Planning steps",
      "Managerial steps"
    ],
    "a": 1,
    "e": "Correct answer: Preliminary steps. Review: Entrepreneurial Process."
  },
  {
    "c": "Entrepreneurial Process",
    "q": "During preliminary steps, what does an entrepreneur primarily do?",
    "o": [
      "Manages employees",
      "Installs machinery",
      "Searches for business opportunities and collects information",
      "Finalizes pricing policy"
    ],
    "a": 2,
    "e": "Correct answer: Searches for business opportunities and collects information. Review: Entrepreneurial Process."
  },
  {
    "c": "Entrepreneurial Process",
    "q": "Decision-making steps involve consulting with which organizations?",
    "o": [
      "WTO and IMF",
      "DIC (District Industrial Centre) and MSME",
      "World Bank and UNDP",
      "SEC and NYSE"
    ],
    "a": 1,
    "e": "Correct answer: DIC (District Industrial Centre) and MSME. Review: Entrepreneurial Process."
  },
  {
    "c": "Entrepreneurial Process",
    "q": "What does PPR stand for in the entrepreneurial process?",
    "o": [
      "Private Placement Regulation",
      "Preliminary Project Report",
      "Product Promotion Review",
      "Planned Productivity Ratio"
    ],
    "a": 1,
    "e": "Correct answer: Preliminary Project Report. Review: Entrepreneurial Process."
  },
  {
    "c": "Entrepreneurial Process",
    "q": "Planning steps include which of the following?",
    "o": [
      "Starting production immediately",
      "Getting loan/capital investment and preparing the Detailed Project Report (DPR)",
      "Distributing finished goods",
      "Firing underperforming staff"
    ],
    "a": 1,
    "e": "Correct answer: Getting loan/capital investment and preparing the Detailed Project Report (DPR). Review: Entrepreneurial Process."
  },
  {
    "c": "Entrepreneurial Process",
    "q": "Implementation steps are best described as:",
    "o": [
      "The stage where ideas are first generated",
      "The execution of the plan — where actual actions take place and real value is generated",
      "The stage of market research",
      "The financial planning phase"
    ],
    "a": 1,
    "e": "Correct answer: The execution of the plan — where actual actions take place and real value is generated. Review: Entrepreneurial Process."
  },
  {
    "c": "Entrepreneurial Process",
    "q": "Which of the following belongs to the \"Managerial Steps\" in the entrepreneurial process?",
    "o": [
      "Applying for environmental clearance",
      "Purchasing land",
      "Formulating pricing policy and managing distribution systems",
      "Installing plant and machinery"
    ],
    "a": 2,
    "e": "Correct answer: Formulating pricing policy and managing distribution systems. Review: Entrepreneurial Process."
  },
  {
    "c": "Entrepreneurial Process",
    "q": "The Detailed Project Report (DPR) is prepared during which phase?",
    "o": [
      "Implementation steps",
      "Managerial steps",
      "Planning steps",
      "Decision-making steps"
    ],
    "a": 2,
    "e": "Correct answer: Planning steps. Review: Entrepreneurial Process."
  },
  {
    "c": "Entrepreneurial Process",
    "q": "\"Making infrastructural development — roads, hospitals, schools, residences\" falls under:",
    "o": [
      "Managerial steps",
      "Planning steps",
      "Decision-making steps",
      "Implementation steps"
    ],
    "a": 3,
    "e": "Correct answer: Implementation steps. Review: Entrepreneurial Process."
  },
  {
    "c": "Starting a Business",
    "q": "Which is NOT a step in the five-step entrepreneurial process?",
    "o": [
      "Preliminary steps",
      "Planning steps",
      "Marketing steps",
      "Managerial steps"
    ],
    "a": 2,
    "e": "Correct answer: Marketing steps. Review: Starting a Business."
  },
  {
    "c": "Starting a Business",
    "q": "Approximately what percentage of new businesses fail within the first three years?",
    "o": [
      "20 percent",
      "40 percent",
      "60 percent",
      "80 percent"
    ],
    "a": 2,
    "e": "Correct answer: 60 percent. Review: Starting a Business."
  },
  {
    "c": "Starting a Business",
    "q": "The \"Apprentice Model\" of business planning refers to:",
    "o": [
      "Partnering with experts",
      "Earning from direct work experience in the industry",
      "Frequently testing and refining the model at low cost",
      "Hiring consultants to develop the plan"
    ],
    "a": 1,
    "e": "Correct answer: Earning from direct work experience in the industry. Review: Starting a Business."
  },
  {
    "c": "Starting a Business",
    "q": "The \"Hired-Gun Approach\" involves:",
    "o": [
      "Earning from direct industry experience",
      "Testing models at low cost",
      "Partnering or sharing with experts who are more knowledgeable",
      "Avoiding partnerships entirely"
    ],
    "a": 2,
    "e": "Correct answer: Partnering or sharing with experts who are more knowledgeable. Review: Starting a Business."
  },
  {
    "c": "Starting a Business",
    "q": "The \"Ultra-Lean School of Hard Knocks Tactic\" focuses on:",
    "o": [
      "Large capital investment",
      "Frequently testing and refining the model at a very reasonable cost",
      "Acquiring established businesses",
      "Going public quickly"
    ],
    "a": 1,
    "e": "Correct answer: Frequently testing and refining the model at a very reasonable cost. Review: Starting a Business."
  },
  {
    "c": "Starting a Business",
    "q": "\"Know the Market\" as a principle for starting a business involves:",
    "o": [
      "Ignoring competitors and focusing on product quality only",
      "Understanding critical market metrics and engaging with suppliers, distributors, competitors, and customers",
      "Relying solely on government market reports",
      "Setting prices without researching the market"
    ],
    "a": 1,
    "e": "Correct answer: Understanding critical market metrics and engaging with suppliers, distributors, competitors, and customers. Review: Starting a Business."
  },
  {
    "c": "Starting a Business",
    "q": "For C Corporations, initial startup losses:",
    "o": [
      "Can be written off on personal tax returns",
      "Produce tax losses that can only be used at the business level",
      "Are automatically waived by the government",
      "Are irrelevant to future tax planning"
    ],
    "a": 1,
    "e": "Correct answer: Produce tax losses that can only be used at the business level. Review: Starting a Business."
  },
  {
    "c": "Starting a Business",
    "q": "For which business structure is there unlimited liability for partners?",
    "o": [
      "C Corporation",
      "S Corporation",
      "LLC",
      "General Partnership / Entrepreneurship"
    ],
    "a": 3,
    "e": "Correct answer: General Partnership / Entrepreneurship. Review: Starting a Business."
  },
  {
    "c": "Starting a Business",
    "q": "\"Double taxation\" is a concern specifically for which business structure?",
    "o": [
      "LLC",
      "S Corporation",
      "C Corporation",
      "Sole proprietorship"
    ],
    "a": 2,
    "e": "Correct answer: C Corporation. Review: Starting a Business."
  },
  {
    "c": "Starting a Business",
    "q": "A cash-flow statement is used to:",
    "o": [
      "List all employees in the company",
      "Evaluate complete expenses and income of the company",
      "Register the business with the government",
      "Determine the price of the product"
    ],
    "a": 1,
    "e": "Correct answer: Evaluate complete expenses and income of the company. Review: Starting a Business."
  },
  {
    "c": "Entrepreneurial Environment",
    "q": "The real value of documenting a business plan lies in:",
    "o": [
      "Having a finished document to show investors",
      "The process of researching and thinking systematically about the business",
      "Avoiding all legal requirements",
      "Eliminating competition before launch"
    ],
    "a": 1,
    "e": "Correct answer: The process of researching and thinking systematically about the business. Review: Entrepreneurial Environment."
  },
  {
    "c": "Entrepreneurial Environment",
    "q": "The three major components community leaders need to address for an entrepreneurial environment are:",
    "o": [
      "Finance, Law, and Technology",
      "Culture, Infrastructure, and Entrepreneurial Support Elements",
      "Marketing, Production, and Distribution",
      "Capital, Land, and Labor"
    ],
    "a": 1,
    "e": "Correct answer: Culture, Infrastructure, and Entrepreneurial Support Elements. Review: Entrepreneurial Environment."
  },
  {
    "c": "Entrepreneurial Environment",
    "q": "The \"Culture\" component of entrepreneurial environment includes:",
    "o": [
      "Building physical roads and schools",
      "Acknowledging entrepreneurs' value, accepting failure, and providing unconditional support",
      "Providing financial loans to entrepreneurs",
      "Regulating tax compliance"
    ],
    "a": 1,
    "e": "Correct answer: Acknowledging entrepreneurs' value, accepting failure, and providing unconditional support. Review: Entrepreneurial Environment."
  },
  {
    "c": "Entrepreneurial Environment",
    "q": "Children of business-owning parents are how much more likely to own a business compared to others?",
    "o": [
      "5 to 10 times",
      "Same likelihood",
      "Two to three times more likely",
      "10 to 20 times"
    ],
    "a": 2,
    "e": "Correct answer: Two to three times more likely. Review: Entrepreneurial Environment."
  },
  {
    "c": "Entrepreneurial Environment",
    "q": "Entrepreneurs who work in their family business before starting their own are reportedly:",
    "o": [
      "Less successful than those who do not",
      "10 to 40 percent more successful than they would otherwise be",
      "Equally successful as those without family business experience",
      "50 to 60 percent more successful"
    ],
    "a": 1,
    "e": "Correct answer: 10 to 40 percent more successful than they would otherwise be. Review: Entrepreneurial Environment."
  },
  {
    "c": "Entrepreneurial Environment",
    "q": "The major role of society in entrepreneurship is:",
    "o": [
      "Regulation and taxation",
      "Support",
      "Competition",
      "Supply of raw materials"
    ],
    "a": 1,
    "e": "Correct answer: Support. Review: Entrepreneurial Environment."
  },
  {
    "c": "Entrepreneurial Environment",
    "q": "Entrepreneurs contribute to society by:",
    "o": [
      "Eliminating government services",
      "Creating job opportunities and ensuring income",
      "Reducing public access to goods",
      "Concentrating wealth among few individuals"
    ],
    "a": 1,
    "e": "Correct answer: Creating job opportunities and ensuring income. Review: Entrepreneurial Environment."
  },
  {
    "c": "Entrepreneurial Environment",
    "q": "The \"Infrastructure\" component of entrepreneurial environment involves:",
    "o": [
      "Only physical infrastructure like roads",
      "Traditional and non-traditional leadership strategies including educational institutions and social enterprises",
      "Financial capital and banking services",
      "Government tax laws only"
    ],
    "a": 1,
    "e": "Correct answer: Traditional and non-traditional leadership strategies including educational institutions and social enterprises. Review: Entrepreneurial Environment."
  },
  {
    "c": "Industrial Policies & Regulations",
    "q": "The drawback of family businesses is that:",
    "o": [
      "They always produce successful outcomes",
      "A cycle of low rates of business ownership and worse business outcomes can be passed across generations",
      "They eliminate competition",
      "They reduce the need for education"
    ],
    "a": 1,
    "e": "Correct answer: A cycle of low rates of business ownership and worse business outcomes can be passed across generations. Review: Industrial Policies & Regulations."
  },
  {
    "c": "Industrial Policies & Regulations",
    "q": "Industrial policy is best defined as:",
    "o": [
      "A government statement on export-import regulations only",
      "A proclamation stating the role of government in industrial development and objectives to be achieved",
      "A private sector document for business planning",
      "A marketing strategy for industrial firms"
    ],
    "a": 1,
    "e": "Correct answer: A proclamation stating the role of government in industrial development and objectives to be achieved. Review: Industrial Policies & Regulations."
  },
  {
    "c": "Industrial Policies & Regulations",
    "q": "The first industrial policy statement of the Government of India was formed in:",
    "o": [
      "1947",
      "1948",
      "1956",
      "1991"
    ],
    "a": 1,
    "e": "Correct answer: 1948. Review: Industrial Policies & Regulations."
  },
  {
    "c": "Industrial Policies & Regulations",
    "q": "The Industrial Policy Resolution of 1956 (IPR 1956) is also known as:",
    "o": [
      "The Trade Constitution",
      "The Economic Constitution of India",
      "The Industrial Licensing Act",
      "The Companies Act"
    ],
    "a": 1,
    "e": "Correct answer: The Economic Constitution of India. Review: Industrial Policies & Regulations."
  },
  {
    "c": "Industrial Policies & Regulations",
    "q": "Under IPR 1956, Schedule A industries referred to:",
    "o": [
      "Companies left entirely to the private sector",
      "Companies progressively state-owned",
      "Companies considered as the exclusive responsibility of the state",
      "Companies exempt from licensing requirements"
    ],
    "a": 2,
    "e": "Correct answer: Companies considered as the exclusive responsibility of the state. Review: Industrial Policies & Regulations."
  },
  {
    "c": "Industrial Policies & Regulations",
    "q": "Schedule C under IPR 1956 referred to:",
    "o": [
      "Industries exclusively managed by the state",
      "Industries progressively owned by the state",
      "Industries left to the private sector's initiative and enterprise",
      "Heavy industries with mandatory licensing"
    ],
    "a": 2,
    "e": "Correct answer: Industries left to the private sector's initiative and enterprise. Review: Industrial Policies & Regulations."
  },
  {
    "c": "Industrial Policies & Regulations",
    "q": "One major objective of industrial policy is \"Prevention of Concentration of Economic Power,\" which means:",
    "o": [
      "Encouraging monopolies for efficiency",
      "Minimizing dominant symptoms and preventing economic power from concentrating in few hands",
      "Increasing the power of large industrial houses",
      "Eliminating small businesses"
    ],
    "a": 1,
    "e": "Correct answer: Minimizing dominant symptoms and preventing economic power from concentrating in few hands. Review: Industrial Policies & Regulations."
  },
  {
    "c": "Industrial Policies & Regulations",
    "q": "The Liberalization of Industrial Licensing Policy currently requires compulsory licensing for how many industries?",
    "o": [
      "Twenty industries",
      "Twelve industries",
      "Six industries",
      "Three industries"
    ],
    "a": 2,
    "e": "Correct answer: Six industries. Review: Industrial Policies & Regulations."
  },
  {
    "c": "Industrial Policies & Regulations",
    "q": "Non-polluting industries like electronics, computer software, and printing can be located within what distance of city boundaries (cities over one million population)?",
    "o": [
      "50 kms",
      "10 kms",
      "5 kms",
      "25 kms"
    ],
    "a": 3,
    "e": "Correct answer: 25 kms. Review: Industrial Policies & Regulations."
  },
  {
    "c": "Industrial Policies & Regulations",
    "q": "The Industrial Entrepreneurs' Memorandum (IEM) must be filed with:",
    "o": [
      "Reserve Bank of India",
      "Secretariat for Industrial Assistance (SIA)",
      "Ministry of Finance",
      "District Industrial Centre"
    ],
    "a": 1,
    "e": "Correct answer: Secretariat for Industrial Assistance (SIA). Review: Industrial Policies & Regulations."
  },
  {
    "c": "International Business",
    "q": "Under the NRI (Non-Resident Indians) Scheme, NRIs are permitted to invest up to what percentage equity on a non-repatriation basis in most activities?",
    "o": [
      "49 percent",
      "60 percent",
      "74 percent",
      "100 percent"
    ],
    "a": 3,
    "e": "Correct answer: 100 percent. Review: International Business."
  },
  {
    "c": "International Business",
    "q": "International business is defined as:",
    "o": [
      "Only export and import of goods between two countries",
      "Commercial transactions — private and governmental — including sales, investments, logistics, and transportation between two or more countries",
      "Joint ventures between private companies only",
      "Online commerce within a single country"
    ],
    "a": 1,
    "e": "Correct answer: Commercial transactions — private and governmental — including sales, investments, logistics, and transportation between two or more countries. Review: International Business."
  },
  {
    "c": "International Business",
    "q": "Which of the following is NOT a major participant in international marketing?",
    "o": [
      "Multi-National Companies (MNCs)",
      "Exporters",
      "Local municipal governments",
      "Service companies"
    ],
    "a": 2,
    "e": "Correct answer: Local municipal governments. Review: International Business."
  },
  {
    "c": "International Business",
    "q": "In international business, \"Licensing\" refers to:",
    "o": [
      "A company setting up factories overseas",
      "Charging a fee or royalty for the use of technology or a brand",
      "Forming a 50-50 joint venture with a foreign company",
      "Hiring international distributors"
    ],
    "a": 1,
    "e": "Correct answer: Charging a fee or royalty for the use of technology or a brand. Review: International Business."
  },
  {
    "c": "International Business",
    "q": "A \"Joint Venture\" in international business means:",
    "o": [
      "One company acquiring another entirely",
      "A new company set up with parties owning half of the business",
      "A company appointing a local agent abroad",
      "Licensing technology to a foreign firm"
    ],
    "a": 1,
    "e": "Correct answer: A new company set up with parties owning half of the business. Review: International Business."
  },
  {
    "c": "International Business",
    "q": "\"Overseas Manufacture or International Sales Subsidiary\" is also known as:",
    "o": [
      "Strategic Alliance",
      "Joint Venture",
      "Foreign Direct Investment (FDI)",
      "Licensing"
    ],
    "a": 2,
    "e": "Correct answer: Foreign Direct Investment (FDI). Review: International Business."
  },
  {
    "c": "International Business",
    "q": "Political Risk in international business refers to:",
    "o": [
      "Risks from currency exchange fluctuations",
      "Risks arising from how a government monitors a nation, including instability from elections or political events",
      "Risks from technological failure",
      "Risks from natural disasters"
    ],
    "a": 1,
    "e": "Correct answer: Risks arising from how a government monitors a nation, including instability from elections or political events. Review: International Business."
  },
  {
    "c": "International Business",
    "q": "Which type of risk arises from a nation's inability to satisfy its financial obligations?",
    "o": [
      "Political Risk",
      "Environmental Risk",
      "Economic Risk",
      "Bribery Risk"
    ],
    "a": 2,
    "e": "Correct answer: Economic Risk. Review: International Business."
  },
  {
    "c": "International Business",
    "q": "Technological Risk in international business includes:",
    "o": [
      "Changes in government leadership",
      "Lack of security in electronic transactions and higher cost of developing new technology",
      "Natural calamities affecting production",
      "Currency devaluation"
    ],
    "a": 1,
    "e": "Correct answer: Lack of security in electronic transactions and higher cost of developing new technology. Review: International Business."
  },
  {
    "c": "International Business",
    "q": "Understanding local culture in international business helps entrepreneurs to:",
    "o": [
      "Eliminate the need for market research",
      "Communicate directly, gain respect, and tailor marketing techniques to the local market",
      "Reduce product quality standards",
      "Avoid dealing with local regulations"
    ],
    "a": 1,
    "e": "Correct answer: Communicate directly, gain respect, and tailor marketing techniques to the local market. Review: International Business."
  },
  {
    "c": "International Business",
    "q": "Geographical factors affecting international business include:",
    "o": [
      "Legal policies and trade agreements",
      "Psychological profiles of employees",
      "Geographical size, climate, natural resources, and population distribution",
      "Interest rate policies"
    ],
    "a": 2,
    "e": "Correct answer: Geographical size, climate, natural resources, and population distribution. Review: International Business."
  },
  {
    "c": "International Business",
    "q": "\"Strategic Alliances\" in international business describe:",
    "o": [
      "Two companies merging completely",
      "A series of different relationships between companies marketing internationally",
      "A company purchasing all assets of a foreign firm",
      "Government-to-government trade agreements"
    ],
    "a": 1,
    "e": "Correct answer: A series of different relationships between companies marketing internationally. Review: International Business."
  },
  {
    "c": "International Business",
    "q": "Financial Risk in international business arises from:",
    "o": [
      "Poor quality management",
      "Fluctuating currency exchange rates and government restrictions on profit repatriation",
      "Lack of employee skills",
      "Natural environmental disasters"
    ],
    "a": 1,
    "e": "Correct answer: Fluctuating currency exchange rates and government restrictions on profit repatriation. Review: International Business."
  },
  {
    "c": "Business Plan",
    "q": "The importance of international business includes creating awareness of:",
    "o": [
      "How to avoid international taxes",
      "The interdependency of one nation's political policies and economic practices on another",
      "Domestic marketing strategies",
      "Internal human resource management"
    ],
    "a": 1,
    "e": "Correct answer: The interdependency of one nation's political policies and economic practices on another. Review: Business Plan."
  },
  {
    "c": "Business Plan",
    "q": "A business plan is best described as:",
    "o": [
      "A short advertisement for a new product",
      "A documented conclusion of how the business will create resources to achieve its goals",
      "A list of employees and their salaries",
      "A legal document for company registration"
    ],
    "a": 1,
    "e": "Correct answer: A documented conclusion of how the business will create resources to achieve its goals. Review: Business Plan."
  },
  {
    "c": "Business Plan",
    "q": "A pre-feasibility study serves as a:",
    "o": [
      "Final business plan",
      "Filter that screens ideas lacking potential for successful entrepreneurship",
      "Marketing campaign plan",
      "Government licensing document"
    ],
    "a": 1,
    "e": "Correct answer: Filter that screens ideas lacking potential for successful entrepreneurship. Review: Business Plan."
  },
  {
    "c": "Business Plan",
    "q": "The three basic stages in product/service selection are:",
    "o": [
      "Research, Development, and Launch",
      "Idea Generation, Evaluation, and Choice",
      "Planning, Financing, and Marketing",
      "Licensing, Manufacturing, and Distribution"
    ],
    "a": 1,
    "e": "Correct answer: Idea Generation, Evaluation, and Choice. Review: Business Plan."
  },
  {
    "c": "Business Plan",
    "q": "\"Social Capital\" for entrepreneurs refers to:",
    "o": [
      "A company's total financial assets",
      "A quality acquired from the structure of an individual's network relationships",
      "Money invested in social media marketing",
      "Government subsidies for social enterprises"
    ],
    "a": 1,
    "e": "Correct answer: A quality acquired from the structure of an individual's network relationships. Review: Business Plan."
  },
  {
    "c": "Business Plan",
    "q": "\"Human Capital\" in entrepreneurship refers to:",
    "o": [
      "The total number of employees in a company",
      "Attributes possessed by individuals like personality, education, intelligence, and job experience",
      "Physical infrastructure like buildings and machinery",
      "Government policies supporting workforce development"
    ],
    "a": 1,
    "e": "Correct answer: Attributes possessed by individuals like personality, education, intelligence, and job experience. Review: Business Plan."
  },
  {
    "c": "Business Plan",
    "q": "\"Financial Capital\" in entrepreneurship is defined as:",
    "o": [
      "The motivation level of the entrepreneur",
      "An economic resource used by entrepreneurs and businesses to purchase what they need",
      "The brand value of the company",
      "Social networks that create business opportunities"
    ],
    "a": 1,
    "e": "Correct answer: An economic resource used by entrepreneurs and businesses to purchase what they need. Review: Business Plan."
  },
  {
    "c": "Business Plan",
    "q": "Sole ownership of a business means:",
    "o": [
      "Sharing all profits with shareholders",
      "All decisions are made alone and all profits are owned by the sole trader",
      "All decisions are made by a board of directors",
      "Liability is limited to the amount invested"
    ],
    "a": 1,
    "e": "Correct answer: All decisions are made alone and all profits are owned by the sole trader. Review: Business Plan."
  },
  {
    "c": "Business Plan",
    "q": "When a business is expanded across a nation and its shares are traded on the stock exchange, it is declared as:",
    "o": [
      "A private company",
      "A partnership",
      "A public company",
      "An LLC"
    ],
    "a": 2,
    "e": "Correct answer: A public company. Review: Business Plan."
  },
  {
    "c": "Business Plan",
    "q": "A business plan must mirror sound standards and illustrate practical assessment of:",
    "o": [
      "Employee happiness",
      "Risk with respect to economic and competitive conditions",
      "Social media engagement",
      "Cultural preferences only"
    ],
    "a": 1,
    "e": "Correct answer: Risk with respect to economic and competitive conditions. Review: Business Plan."
  },
  {
    "c": "Growth Strategies in Business",
    "q": "The source of product for a new business means:",
    "o": [
      "Inventing entirely new technology",
      "Searching for products at an average price that can be resold at a retail price",
      "Acquiring competitors' product lines",
      "Importing products without any quality screening"
    ],
    "a": 1,
    "e": "Correct answer: Searching for products at an average price that can be resold at a retail price. Review: Growth Strategies in Business."
  },
  {
    "c": "Growth Strategies in Business",
    "q": "\"Market Penetration\" as a growth strategy involves:",
    "o": [
      "Selling new products in new markets",
      "Acquiring another company",
      "Marketing existing products within the same market to increase market share",
      "Selling current products in a new geographic market"
    ],
    "a": 2,
    "e": "Correct answer: Marketing existing products within the same market to increase market share. Review: Growth Strategies in Business."
  },
  {
    "c": "Growth Strategies in Business",
    "q": "The best way to increase market share through market penetration is:",
    "o": [
      "Increasing advertising spending only",
      "Lowering the prices of commodities",
      "Launching entirely new product lines",
      "Acquiring competitor companies"
    ],
    "a": 1,
    "e": "Correct answer: Lowering the prices of commodities. Review: Growth Strategies in Business."
  },
  {
    "c": "Growth Strategies in Business",
    "q": "\"Market Expansion\" (also called market development) involves:",
    "o": [
      "Selling existing products in new markets",
      "Selling new products in existing markets",
      "Selling both new products and entering new markets simultaneously",
      "Acquiring existing competitors"
    ],
    "a": 0,
    "e": "Correct answer: Selling existing products in new markets. Review: Growth Strategies in Business."
  },
  {
    "c": "Growth Strategies in Business",
    "q": "\"Product Expansion\" is also referred to as:",
    "o": [
      "Market penetration",
      "Diversification",
      "Product development",
      "Acquisition"
    ],
    "a": 2,
    "e": "Correct answer: Product development. Review: Growth Strategies in Business."
  },
  {
    "c": "Growth Strategies in Business",
    "q": "Product expansion growth strategy works best when:",
    "o": [
      "There is no competition",
      "The company wants to enter a new geographic market",
      "There is a change in technology or older products become outdated",
      "The company is acquiring another business"
    ],
    "a": 2,
    "e": "Correct answer: There is a change in technology or older products become outdated. Review: Growth Strategies in Business."
  },
  {
    "c": "Growth Strategies in Business",
    "q": "\"Diversification\" as a growth strategy involves:",
    "o": [
      "Selling existing products in existing markets",
      "Selling new products in new markets — the riskiest strategy",
      "Selling existing products in new markets",
      "Buying out a competitor"
    ],
    "a": 1,
    "e": "Correct answer: Selling new products in new markets — the riskiest strategy. Review: Growth Strategies in Business."
  },
  {
    "c": "Growth Strategies in Business",
    "q": "Why is \"Acquisition\" considered less risky than diversification?",
    "o": [
      "Because it requires less capital investment",
      "Because the products and market are already authorized/established",
      "Because it involves no legal complications",
      "Because it focuses on existing products in existing markets"
    ],
    "a": 1,
    "e": "Correct answer: Because the products and market are already authorized/established. Review: Growth Strategies in Business."
  },
  {
    "c": "Growth Strategies in Business",
    "q": "Marketing research in a diversification growth strategy is important to:",
    "o": [
      "Lower production costs",
      "Identify if consumers in the new market will potentially like and buy the new products",
      "Determine the best pricing strategy for existing markets",
      "Recruit qualified employees"
    ],
    "a": 1,
    "e": "Correct answer: Identify if consumers in the new market will potentially like and buy the new products. Review: Growth Strategies in Business."
  },
  {
    "c": "Product Launch",
    "q": "Which growth strategy involves a company purchasing another company to expand its functions?",
    "o": [
      "Market expansion",
      "Product expansion",
      "Diversification",
      "Acquisition"
    ],
    "a": 3,
    "e": "Correct answer: Acquisition. Review: Product Launch."
  },
  {
    "c": "Product Launch",
    "q": "How many weeks before an official release date should outreach practices ideally begin?",
    "o": [
      "1 to 2 weeks",
      "3 to 5 weeks",
      "6 to 8 weeks",
      "10 to 12 weeks"
    ],
    "a": 2,
    "e": "Correct answer: 6 to 8 weeks. Review: Product Launch."
  },
  {
    "c": "Product Launch",
    "q": "\"Influencers\" in a product launch context can be:",
    "o": [
      "Only professional journalists",
      "Cordial customers, prospects, or bloggers with a notable online presence",
      "Only investors and shareholders",
      "Only government regulatory authorities"
    ],
    "a": 1,
    "e": "Correct answer: Cordial customers, prospects, or bloggers with a notable online presence. Review: Product Launch."
  },
  {
    "c": "Product Launch",
    "q": "\"Fill the social space with leaks\" in a product launch means:",
    "o": [
      "Sharing confidential financial data",
      "Creating intrigue through 'arriving shortly' posts and 'leaked' photos before the official launch",
      "Deliberately spreading false information",
      "Filing media complaints"
    ],
    "a": 1,
    "e": "Correct answer: Creating intrigue through 'arriving shortly' posts and 'leaked' photos before the official launch. Review: Product Launch."
  },
  {
    "c": "Product Launch",
    "q": "Step 5 of the product launch process advises entrepreneurs to:",
    "o": [
      "Expect a massive \"big bang\" release every time",
      "Not expect a \"big bang\" release unless the product is truly revolutionary",
      "Launch secretly without any prior announcement",
      "Release the product only through physical stores"
    ],
    "a": 1,
    "e": "Correct answer: Not expect a \"big bang\" release unless the product is truly revolutionary. Review: Product Launch."
  },
  {
    "c": "Product Launch",
    "q": "\"Keep the release rolling\" advises entrepreneurs to:",
    "o": [
      "Launch multiple products simultaneously",
      "Update with fresh news like discounts, customer stories, and ROI details after the official launch",
      "Stop all promotional activities after launch day",
      "Focus only on social media metrics like likes"
    ],
    "a": 1,
    "e": "Correct answer: Update with fresh news like discounts, customer stories, and ROI details after the official launch. Review: Product Launch."
  },
  {
    "c": "Product Launch",
    "q": "\"Involving all partners\" during a product launch is advisable because:",
    "o": [
      "It reduces the entrepreneur's workload",
      "More people talking about the launch increases the chances of gaining market share",
      "Partners share financial risks",
      "It satisfies government regulatory requirements"
    ],
    "a": 1,
    "e": "Correct answer: More people talking about the launch increases the chances of gaining market share. Review: Product Launch."
  },
  {
    "c": "Product Launch",
    "q": "\"Making the product accessible\" includes:",
    "o": [
      "Restricting access to create exclusivity",
      "Free trials, downloads, product videos, and demos",
      "Selling only through premium channels",
      "Delaying access to build demand"
    ],
    "a": 1,
    "e": "Correct answer: Free trials, downloads, product videos, and demos. Review: Product Launch."
  },
  {
    "c": "Product Launch",
    "q": "Step 10 of the product launch process advises entrepreneurs to:",
    "o": [
      "Focus heavily on social media metrics like Facebook likes",
      "Ignore elements that do not drive the business; use social channels for meaningful engagement",
      "Stop engaging with customers after launch",
      "Reduce product variety to focus on bestsellers"
    ],
    "a": 1,
    "e": "Correct answer: Ignore elements that do not drive the business; use social channels for meaningful engagement. Review: Product Launch."
  },
  {
    "c": "Product Launch",
    "q": "\"Doing something unusual\" during a product launch is aimed at:",
    "o": [
      "Confusing competitors",
      "Generating curiosity and grabbing attention beyond conventional launch methods",
      "Satisfying legal requirements",
      "Reducing marketing costs"
    ],
    "a": 1,
    "e": "Correct answer: Generating curiosity and grabbing attention beyond conventional launch methods. Review: Product Launch."
  },
  {
    "c": "Case Study — Women Entrepreneurship in Pakistan",
    "q": "\"Briefing industry analysts\" is recommended during which phase of the product launch?",
    "o": [
      "After the product fails",
      "The initial phase — scheduling calls and preparing compelling briefing requests",
      "Only after the product has been in the market for six months",
      "After receiving customer feedback"
    ],
    "a": 1,
    "e": "Correct answer: The initial phase — scheduling calls and preparing compelling briefing requests. Review: Case Study — Women Entrepreneurship in Pakistan."
  },
  {
    "c": "Case Study — Women Entrepreneurship in Pakistan",
    "q": "Pakistan ranks how poorly on the Global Gender Gap Index (2020)?",
    "o": [
      "First worst",
      "Second worst",
      "Third worst",
      "Fifth worst"
    ],
    "a": 2,
    "e": "Correct answer: Third worst. Review: Case Study — Women Entrepreneurship in Pakistan."
  },
  {
    "c": "Case Study — Women Entrepreneurship in Pakistan",
    "q": "Women's contribution to GDP in terms of paid work in Pakistan is the lowest in Asia Pacific at:",
    "o": [
      "5 percent",
      "8 percent",
      "11 percent",
      "15 percent"
    ],
    "a": 2,
    "e": "Correct answer: 11 percent. Review: Case Study — Women Entrepreneurship in Pakistan."
  },
  {
    "c": "Case Study — Women Entrepreneurship in Pakistan",
    "q": "What percentage of women in Pakistan have access to formal financial services?",
    "o": [
      "6 percent",
      "12 percent",
      "21 percent",
      "30 percent"
    ],
    "a": 0,
    "e": "Correct answer: 6 percent. Review: Case Study — Women Entrepreneurship in Pakistan."
  },
  {
    "c": "Case Study — Women Entrepreneurship in Pakistan",
    "q": "Pakistan ranks last among how many countries on the Female Entrepreneurship Index (FEI) 2015?",
    "o": [
      "50 countries",
      "65 countries",
      "77 countries",
      "100 countries"
    ],
    "a": 2,
    "e": "Correct answer: 77 countries. Review: Case Study — Women Entrepreneurship in Pakistan."
  },
  {
    "c": "Case Study — Women Entrepreneurship in Pakistan",
    "q": "Women entrepreneurs in Pakistan account for what percentage of MSME owners?",
    "o": [
      "2 percent",
      "5 percent",
      "8 percent",
      "15 percent"
    ],
    "a": 2,
    "e": "Correct answer: 8 percent. Review: Case Study — Women Entrepreneurship in Pakistan."
  },
  {
    "c": "Case Study — Women Entrepreneurship in Pakistan",
    "q": "Only what percentage of women in Pakistan are engaged in entrepreneurial activities?",
    "o": [
      "1 percent",
      "5 percent",
      "10 percent",
      "15 percent"
    ],
    "a": 0,
    "e": "Correct answer: 1 percent. Review: Case Study — Women Entrepreneurship in Pakistan."
  },
  {
    "c": "Case Study — Women Entrepreneurship in Pakistan",
    "q": "The SBP launched which scheme in 2019 to help women entrepreneurs?",
    "o": [
      "National Financial Inclusion Strategy",
      "Refinance and Credit Guarantee Scheme for Women Entrepreneurs",
      "Ehsaas Programme",
      "We-Fi Initiative"
    ],
    "a": 1,
    "e": "Correct answer: Refinance and Credit Guarantee Scheme for Women Entrepreneurs. Review: Case Study — Women Entrepreneurship in Pakistan."
  },
  {
    "c": "Case Study — Women Entrepreneurship in Pakistan",
    "q": "Samina Masood is the CEO of which company?",
    "o": [
      "M-Tex Embroideries Ltd.",
      "Karandaaz Pakistan",
      "Murad Textiles (Pvt) Limited (M-Tex)",
      "SMEDA Textiles"
    ],
    "a": 2,
    "e": "Correct answer: Murad Textiles (Pvt) Limited (M-Tex). Review: Case Study — Women Entrepreneurship in Pakistan."
  },
  {
    "c": "Case Study — Women Entrepreneurship in Pakistan",
    "q": "Samina Masood started her business in which year?",
    "o": [
      "2010",
      "2012",
      "2014",
      "2016"
    ],
    "a": 2,
    "e": "Correct answer: 2014. Review: Case Study — Women Entrepreneurship in Pakistan."
  },
  {
    "c": "Case Study — Women Entrepreneurship in Pakistan",
    "q": "Before becoming an entrepreneur, Samina Masood worked for 18 years as:",
    "o": [
      "A schoolteacher",
      "A bank manager",
      "A librarian at a private school system in Lahore",
      "A fashion designer"
    ],
    "a": 2,
    "e": "Correct answer: A librarian at a private school system in Lahore. Review: Case Study — Women Entrepreneurship in Pakistan."
  },
  {
    "c": "Case Study — Women Entrepreneurship in Pakistan",
    "q": "Karandaaz provided M-Tex with funding of how much capital?",
    "o": [
      "Rs 15 million",
      "Rs 25 million",
      "Rs 35 million",
      "Rs 50 million"
    ],
    "a": 2,
    "e": "Correct answer: Rs 35 million. Review: Case Study — Women Entrepreneurship in Pakistan."
  },
  {
    "c": "Case Study — Women Entrepreneurship in Pakistan",
    "q": "What was the growth in M-Tex's revenues in Year 1 of Karandaaz's support?",
    "o": [
      "10 percent",
      "15 percent",
      "20 percent",
      "27 percent"
    ],
    "a": 3,
    "e": "Correct answer: 27 percent. Review: Case Study — Women Entrepreneurship in Pakistan."
  },
  {
    "c": "Case Study — Women Entrepreneurship in Pakistan",
    "q": "Which of the following is a recommendation from the case study to improve women entrepreneurship in Pakistan?",
    "o": [
      "Reducing access to microfinance for women",
      "Encouraging only large-scale business ventures by women",
      "Increasing digitalization, introducing movable collateral, and providing customized training with long-term mentorship",
      "Reducing government intervention in private sector businesses"
    ],
    "a": 2,
    "e": "Correct answer: Increasing digitalization, introducing movable collateral, and providing customized training with long-term mentorship. Review: Case Study — Women Entrepreneurship in Pakistan."
  },
  {
    "c": "Finance & Pricing",
    "q": "What does 'business' fundamentally mean in the context of entrepreneurship?",
    "o": [
      "A social activity to serve the public",
      "A legal way to earn profit while keeping financial risk in mind",
      "Any activity generating income regardless of legality",
      "A government-authorized non-profit venture"
    ],
    "a": 1,
    "e": "Business is defined as a legal way to earn profit, keeping financial risk in mind — legality and risk are both essential components."
  },
  {
    "c": "PESTLE Analysis",
    "q": "What does 'legal' mean in the context of starting a business?",
    "o": [
      "Having ethical values",
      "Earning maximum profit",
      "Following procedures, rules, and regulations with government permission",
      "Avoiding competition in the market"
    ],
    "a": 2,
    "e": "Legal means following procedures, rules, and regulations with the permission of the government — not just ethics or profit."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "In entrepreneurship, 'risk' is best described as:",
    "o": [
      "Guaranteed loss of capital",
      "Certainty of profit",
      "Uncertainty involving both profit and loss",
      "A controllable internal factor"
    ],
    "a": 2,
    "e": "Risk means uncertainty — it includes both the possibility of profit and the possibility of loss."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "According to the notes, if you are getting 80% loss and 20% profit, you should:",
    "o": [
      "Immediately close the business",
      "Fear the loss and exit the market",
      "Stay focused on the 20% profit and apply special techniques to enhance business",
      "Report the loss to FBR"
    ],
    "a": 2,
    "e": "The note says your fear of loss will give real loss. You should stay focused on the 20% profit and apply special techniques."
  },
  {
    "c": "Legal & Registration",
    "q": "FBR stands for:",
    "o": [
      "Financial Budget Registry",
      "Federal Bureau of Revenue",
      "Federal Board of Revenue",
      "Fiscal Business Regulation"
    ],
    "a": 2,
    "e": "FBR stands for Federal Board of Revenue."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "Before starting a business, the question 'How?' is specifically linked to:",
    "o": [
      "Market demand",
      "Financial position",
      "Target audience",
      "Government regulations"
    ],
    "a": 1,
    "e": "'How' is linked with financial position — how much capital you have."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "An 'active partner' in a business differs from a 'sleeping partner' in that:",
    "o": [
      "Active partners invest more money",
      "Active partners have direct involvement; sleeping partners invest but are not directly involved",
      "Sleeping partners take all decisions",
      "Active partners have low chances of corruption"
    ],
    "a": 1,
    "e": "Active partners have direct involvement in the business, while sleeping partners invest but are not directly involved."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "A 'Portfolio' in business context means:",
    "o": [
      "A collection of marketing strategies",
      "Opening another business elsewhere to avoid loss from the first",
      "A legal document for government registration",
      "A financial report submitted to FBR"
    ],
    "a": 1,
    "e": "Portfolio: if a person starts a business but to avoid loss, he opens another business somewhere else."
  },
  {
    "c": "PESTLE Analysis",
    "q": "CSR (Corporate Social Responsibility) means:",
    "o": [
      "Following tax regulations strictly",
      "Keeping in mind the comfort and discomfort of the society",
      "Ensuring maximum profit for shareholders",
      "Reducing competition in the market"
    ],
    "a": 1,
    "e": "CSR means keeping in mind the comfort and discomfort of the society."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "Entrepreneurship is formally defined as:",
    "o": [
      "The act of registering a business with SECP",
      "The process of developing, organizing, and running a new business keeping in mind the financial risk",
      "Starting a business with government funding",
      "Managing an existing business to maximize profit"
    ],
    "a": 1,
    "e": "Entrepreneurship is the process of developing, organizing, and running new business keeping in mind the financial risk."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "Which of the following is a disadvantage of entrepreneurship related to work-life balance?",
    "o": [
      "Great responsibility",
      "Fraud",
      "Long working hours causing mental and physical health disturbance",
      "Financial risk"
    ],
    "a": 2,
    "e": "Long working hours (workaholic tendency) disturbs mental and physical health and damages work-life balance."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "'Work life balance' in entrepreneurship means:",
    "o": [
      "Working 24/7 for profit",
      "Balancing professional life and family life equally",
      "Reducing work hours to increase personal time",
      "Hiring staff to manage personal life"
    ],
    "a": 1,
    "e": "Work life balance means professional life equals family life — maintaining balance between the two."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "In the context of competition as a disadvantage, 'Monopoly' means:",
    "o": [
      "Many competitors in the same market",
      "No competitors or fewer competitors",
      "A government-controlled market",
      "A business with multiple product lines"
    ],
    "a": 1,
    "e": "Monopoly means no competitors or less competition — it is described under competition as a business disadvantage."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "FMCGs stands for:",
    "o": [
      "Financial Management and Capital Goods",
      "Fast Moving Consumer Goods — daily usage products",
      "Federal Market Consumer Groups",
      "Fixed Manufacturing Cost Goods"
    ],
    "a": 1,
    "e": "FMCGs = daily usage products (Fast Moving Consumer Goods)."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "Financial risk in entrepreneurship refers to:",
    "o": [
      "The cost of legal registration",
      "The probability of failure or success",
      "The amount of tax paid to FBR",
      "The startup capital required"
    ],
    "a": 1,
    "e": "Financial risk refers to the probability of failure or success — it is about uncertainty of financial outcomes."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "A 'fallacy' in business context (as mentioned in notes) means:",
    "o": [
      "A marketing strategy",
      "A type of patent",
      "When someone tries to destroy your business",
      "A false financial report"
    ],
    "a": 2,
    "e": "Fallacy = when someone tries to destroy your business."
  },
  {
    "c": "SWOT Analysis",
    "q": "SWOT analysis is primarily used for:",
    "o": [
      "Registering a business with SECP",
      "Analyzing competitors and business rivals",
      "Calculating tax obligations",
      "Determining product pricing"
    ],
    "a": 1,
    "e": "SWOT analysis is for your competitors, for your business rivals."
  },
  {
    "c": "PESTLE Analysis",
    "q": "In PEST analysis, what does 'S' stand for?",
    "o": [
      "Strategic",
      "Sales",
      "Social",
      "Stakeholder"
    ],
    "a": 2,
    "e": "In PEST, S = Social — covering demographics, social attitudes, culture, education level, social welfare."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "'Drone Entrepreneurship' refers to:",
    "o": [
      "Using drones in business operations",
      "A typical/stereotypical entrepreneur who resists change and uses traditional methods",
      "A technology-focused entrepreneur",
      "An entrepreneur who invests in multiple businesses"
    ],
    "a": 1,
    "e": "Drone Entrepreneurship = typical or stereotypical entrepreneur who does not want any change, uses traditional ways, and fears competition."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "'Techno Entrepreneurship' is best described as:",
    "o": [
      "An entrepreneur who manufactures technology products",
      "An entrepreneur who uses and adopts new technology in business — opposite of drone entrepreneurship",
      "A person who only runs e-commerce businesses",
      "An entrepreneur focused on agricultural technology"
    ],
    "a": 1,
    "e": "Techno Entrepreneur wants technology in business, introduces new ways to attract customers — opposite of drone entrepreneurship."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "A 'Barter System' involves:",
    "o": [
      "Exchange of currency for goods",
      "Exchange of products/goods directly without money",
      "A digital payment system",
      "A government trading policy"
    ],
    "a": 1,
    "e": "Barter system = exchange of product/goods — it can be a physical entity, service, or something abstract."
  },
  {
    "c": "Legal & Registration",
    "q": "'Ethnocentrism' in business includes concepts like:",
    "o": [
      "Technology, innovation, and patents",
      "Tokenism, taboos, stereotypes, and family beliefs/rituals",
      "Demographics, age, and income",
      "Financial risk and market competition"
    ],
    "a": 1,
    "e": "Ethnocentrism is about race and culture — includes tokenism, taboos, stereotypes, family beliefs, and rituals."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "'Demographics' in business targeting refers to:",
    "o": [
      "The geographic location of a business",
      "Targeting based on gender, age, religion, country, race, education, income, or experience",
      "The cultural practices of a society",
      "The legal structure of a business"
    ],
    "a": 1,
    "e": "Demographics = when you target anybody based on gender, age, religion, country, race, education, specific product experience, or income."
  },
  {
    "c": "PESTLE Analysis",
    "q": "'Social Entrepreneurs' are primarily:",
    "o": [
      "Entrepreneurs who use social media for marketing",
      "Entrepreneurs related to society",
      "Entrepreneurs who sell social goods",
      "Entrepreneurs who work in government"
    ],
    "a": 1,
    "e": "Social Entrepreneurs are related to society."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "'Agriculture Entrepreneurship' involves:",
    "o": [
      "Developing new farm technologies",
      "Giving financial aid to farmers",
      "Importing agricultural products",
      "Exporting crops internationally"
    ],
    "a": 1,
    "e": "Agriculture Entrepreneurship = give financial aid to farmers."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "'Culture' in the context of entrepreneurship is defined as:",
    "o": [
      "The legal framework of a country",
      "Living standards that pass onto the next generation — the way of life that transfers from one generation to another (heritage)",
      "The religious beliefs of business owners",
      "Government policies affecting business"
    ],
    "a": 1,
    "e": "Culture = living standards that pass onto the next generation; the way of life which transfers from one generation to another — heritage."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "The first step in starting a small business in Pakistan is:",
    "o": [
      "Legal Structure",
      "Registration with SECP",
      "Business Research and Ideas (including market research)",
      "Financial Setup"
    ],
    "a": 2,
    "e": "The first step is Business Research and Ideas — also known as market research (observation research, database system)."
  },
  {
    "c": "Marketing & Customers",
    "q": "'Market Research' in business planning helps you understand:",
    "o": [
      "Government tax rates",
      "Your target audience, competition, and market trends",
      "How to register with FBR",
      "Employee salary structures"
    ],
    "a": 1,
    "e": "Market Research helps you target your audience, understand competition, and identify market trends."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "A Business Plan must include:",
    "o": [
      "Only the marketing strategy",
      "Goals, revenue model, financial projection, investors, labour cost, and capital",
      "Only the legal registration documents",
      "The owner's personal financial history"
    ],
    "a": 1,
    "e": "Business Plan includes: Goals, Revenue, Model, Financial Projection, Investors, Labour cost, Capital (building), Shareholders."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "A 'Stakeholder' is defined as:",
    "o": [
      "Only the shareholders of a company",
      "360° — all those who are benefiting from that business",
      "Only the customers",
      "Only the employees and managers"
    ],
    "a": 1,
    "e": "Stakeholder = 360° — those who are benefiting from that business (everyone affected/benefiting)."
  },
  {
    "c": "PESTLE Analysis",
    "q": "'Legal Structure' in starting a business refers to:",
    "o": [
      "Hiring a legal team",
      "Partnership and tax implication decisions",
      "Getting NOC from local authorities",
      "Choosing the business location"
    ],
    "a": 1,
    "e": "Legal Structure covers partnership and tax implications."
  },
  {
    "c": "Legal & Registration",
    "q": "For registration in Pakistan, 'SECP' stands for:",
    "o": [
      "State Exchange and Commerce Pakistan",
      "Securities Exchange and Commission of Pakistan",
      "Standard Enterprise Compliance Protocol",
      "Securities Exchange and Commission of Pakistan"
    ],
    "a": 1,
    "e": "SECP = Securities Exchange and Commission of Pakistan — where stock exchange registration occurs."
  },
  {
    "c": "Legal & Registration",
    "q": "'NTN' in Pakistani business registration stands for:",
    "o": [
      "New Trade Number",
      "National Tax Number",
      "National Trade Network",
      "Net Transfer Number"
    ],
    "a": 1,
    "e": "NTN = National Tax Number (also called Filer)."
  },
  {
    "c": "Legal & Registration",
    "q": "'STRN' refers to:",
    "o": [
      "Standard Trade Registration Number",
      "Sales Tax Registration Number",
      "State Trade Revenue Number",
      "Systematic Tax Rate Notification"
    ],
    "a": 1,
    "e": "STRN = Sales Tax Registration Number, registered with the Federal Board of Revenue."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "'Financial Setup' as a step in starting a business includes:",
    "o": [
      "Choosing investors only",
      "Bank account and Record Keeping System",
      "Only tax filing",
      "Marketing budget allocation"
    ],
    "a": 1,
    "e": "Financial Setup = Bank account and Record Keeping System."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "'Intrinsic motivation' differs from 'extrinsic motivation' in that:",
    "o": [
      "Intrinsic is driven by external rewards; extrinsic is internal",
      "Intrinsic comes from within oneself; extrinsic comes from external factors",
      "Both are identical in family businesses",
      "Intrinsic only applies to social entrepreneurs"
    ],
    "a": 1,
    "e": "Intrinsic motivation is internal (personal drive); extrinsic motivation is external (rewards, recognition)."
  },
  {
    "c": "SWOT Analysis",
    "q": "SWOT Analysis was introduced in:",
    "o": [
      "1940",
      "1970",
      "1960",
      "1980"
    ],
    "a": 2,
    "e": "SWOT analysis was introduced in 1960, by Albert Humphrey."
  },
  {
    "c": "SWOT Analysis",
    "q": "In SWOT, Strength and Weakness are classified as:",
    "o": [
      "Uncontrollable external factors",
      "Controllable internal factors",
      "Uncontrollable internal factors",
      "Controllable external factors"
    ],
    "a": 1,
    "e": "Strength and Weakness are controllable INTERNAL factors; Opportunities and Threats are uncontrollable EXTERNAL factors."
  },
  {
    "c": "SWOT Analysis",
    "q": "SWOT's main aim is to:",
    "o": [
      "Calculate tax obligations",
      "Evaluate a company's competitive positions and develop strategic planning connected with vision and mission",
      "Register a business legally",
      "Identify target demographics"
    ],
    "a": 1,
    "e": "Its main aim is to evaluate company's competitive positions and develop strategic planning connected with vision and mission."
  },
  {
    "c": "SWOT Analysis",
    "q": "'Strength' in SWOT refers to:",
    "o": [
      "External favorable conditions",
      "Positive qualities that separate you from competitors — positive attributes to differentiate your product",
      "Internal weaknesses to fix",
      "Market threats from outside"
    ],
    "a": 1,
    "e": "Strength = positive quality, separate from competitor. Positive attributes of any product to differentiate your product from competitors."
  },
  {
    "c": "SWOT Analysis",
    "q": "Which of the following is an example of a business 'Weakness' in SWOT?",
    "o": [
      "Loyal customers and strong brand",
      "Unique technology and pricing strategy",
      "Weak brand, high prices, low quality, less promotion, outdated technology, unqualified staff",
      "Favorable government policy"
    ],
    "a": 2,
    "e": "Weaknesses include: weak brand, supply chain issues, high prices, low quality, less promotion, outdated technology, unqualified staff."
  },
  {
    "c": "SWOT Analysis",
    "q": "'Opportunities' in SWOT analysis refers to:",
    "o": [
      "Internal positive attributes",
      "Threats from competitors",
      "Favorable environment for stakeholders and customers",
      "Weaknesses to be improved"
    ],
    "a": 2,
    "e": "Opportunities = favorable environment for stakeholders and customers."
  },
  {
    "c": "SWOT Analysis",
    "q": "'Threats' in SWOT analysis refer to:",
    "o": [
      "Internal weaknesses of the business",
      "Factors that have potential to harm the organization or product (e.g., natural disasters, drought)",
      "Customer complaints",
      "Competitor pricing strategies only"
    ],
    "a": 1,
    "e": "Threats = factors that have potential harm to organization or product. Example: drought reducing wheat production, natural disasters."
  },
  {
    "c": "PESTLE Analysis",
    "q": "In PEST Analysis, the 'P' (Political) factor includes:",
    "o": [
      "Population demographics",
      "Exchange rates and inflation",
      "Bureaucratic stability, government policies, tax policies, trade regulation, and FBR responsibility",
      "Technological research and development"
    ],
    "a": 2,
    "e": "Political factors include bureaucratic stability, government policies, tax policies, trade regulation (FBR responsibility), and governmental leadership (ministries)."
  },
  {
    "c": "PESTLE Analysis",
    "q": "In PEST, the 'E' (Economical) factor covers:",
    "o": [
      "Employee welfare and health",
      "Exchange rate, currency stability, inflation rate, economic growth, and economic indicators",
      "Environmental climate changes",
      "Education level and social welfare"
    ],
    "a": 1,
    "e": "Economic factors include economic growth, inflation rate, economic indicators, exchange rate, and currency stability."
  },
  {
    "c": "PESTLE Analysis",
    "q": "In an extended PEST (PESTLE), what does 'E' as an additional factor stand for?",
    "o": [
      "E-commerce factors",
      "Economic growth indicators",
      "Environmental factors — climate changes and natural disasters",
      "Educational factors"
    ],
    "a": 2,
    "e": "E = Environmental factors → Climate changes, Natural disasters (newly added to extend PEST)."
  },
  {
    "c": "PESTLE Analysis",
    "q": "'Legal factors' in PESTLE analysis involve:",
    "o": [
      "Tax filing procedures",
      "Following International Labour Law, employee law, and employee health and safety regulations",
      "Marketing regulations only",
      "Company registration procedures"
    ],
    "a": 1,
    "e": "Legal factors = follow International Labour Law, Employees law, employee's health and safety regulations."
  },
  {
    "c": "Finance & Pricing",
    "q": "'Limited Capital' as a financial challenge in entrepreneurship refers to:",
    "o": [
      "Insufficient marketing budget",
      "Limited land, labour, and machinery",
      "Inability to pay taxes",
      "Low customer demand"
    ],
    "a": 1,
    "e": "Limited Capital → land, labour, machinery — these are the three main capital components that may be limited."
  },
  {
    "c": "Finance & Pricing",
    "q": "'Cash Flow Management' in entrepreneurship involves:",
    "o": [
      "Managing social media accounts",
      "Tracking the flow from production to end user, managing supplier, labor, and operation costs",
      "Filing annual tax returns",
      "Setting product prices"
    ],
    "a": 1,
    "e": "Cash Flow Management: Production → End user → Cost; covers Supplier, labor, Operation cost."
  },
  {
    "c": "Marketing & Customers",
    "q": "'Market Saturation' as a competitive hurdle means:",
    "o": [
      "A market with no products available",
      "Many competitors at the same place",
      "A market dominated by one monopoly",
      "Low customer demand in the market"
    ],
    "a": 1,
    "e": "Market Saturation = many competitors at same place — too crowded a market."
  },
  {
    "c": "PESTLE Analysis",
    "q": "'Legal hurdles' in entrepreneurship include:",
    "o": [
      "Employee recruitment challenges",
      "Rules, regulations, intellectual property issues, Local/International NOC requirements",
      "Marketing strategy failures",
      "Financial investment shortages"
    ],
    "a": 1,
    "e": "Legal hurdles = rules and regulations, intellectual properties issues, Local/International requirements, NOC."
  },
  {
    "c": "Marketing & Customers",
    "q": "Which of the following best describes 'Marketing Management' as a hurdle?",
    "o": [
      "Managing the production process",
      "Promotion using traditional ways, technological, social or print media",
      "Managing customer complaints",
      "Setting sales targets"
    ],
    "a": 1,
    "e": "Marketing management = for promotion — using traditional ways, technological, social, or print media."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "'Emotional Stability/Challenges' in entrepreneurship include:",
    "o": [
      "Financial losses only",
      "Stress, anxiety, and isolation",
      "Market competition and pricing",
      "Legal compliance issues"
    ],
    "a": 1,
    "e": "Emotional Stability/Challenges = stress, anxiety, isolation — the psychological toll of entrepreneurship."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "Which of the following is listed as an importance of entrepreneurship?",
    "o": [
      "Increases government taxation",
      "Reduces innovation and competition",
      "Jobs creation, wealth generation, economic growth, and innovations",
      "Limits individual freedom"
    ],
    "a": 2,
    "e": "Importance of entrepreneurship includes: jobs creation, lifestyle changes, wealth generation, economic growth, community development, self-employment, decision making, innovations, stability of currency, work flexibility, leadership qualities, globalization."
  },
  {
    "c": "SWOT Analysis",
    "q": "'Strategic Planning' as an importance of SWOT Analysis involves:",
    "o": [
      "Only external capabilities",
      "Internal and external capabilities plus backup planning",
      "Only financial budgeting",
      "Performance evaluation alone"
    ],
    "a": 1,
    "e": "Strategic Planning = internal capabilities + external capabilities + backup planning."
  },
  {
    "c": "SWOT Analysis",
    "q": "'Resource Allocation' in SWOT importance refers to:",
    "o": [
      "Choosing the business location",
      "Allocating human, financial, and capital resources; finance = money circulation/budgeting and raw material",
      "Legal registration processes",
      "Marketing campaign budgets"
    ],
    "a": 1,
    "e": "Resource Allocation = Human, financial, capital resource. Finance → money circulation/Budgeting, raw material."
  },
  {
    "c": "SWOT Analysis",
    "q": "'Performance Evaluation' as an importance of SWOT means:",
    "o": [
      "Evaluating employees annually",
      "Comparing previous and ongoing performance",
      "Conducting PEST analysis",
      "Setting new business goals"
    ],
    "a": 1,
    "e": "Performance Evaluation = compare previous and ongoing performance."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "'Corporate Entrepreneurship' is also known as:",
    "o": [
      "E-commerce Entrepreneurship",
      "Social Entrepreneurship",
      "Intrapreneurship",
      "Green Entrepreneurship"
    ],
    "a": 2,
    "e": "Corporate Entrepreneurship = Intrapreneurs — entrepreneurs who work within an existing corporation."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "In business planning, the four foundational elements in order are:",
    "o": [
      "Goals, objectives, mission, vision",
      "Vision, Mission, Goals, Objectives",
      "Objectives, Goals, Vision, Mission",
      "Mission, Vision, Objectives, Goals"
    ],
    "a": 1,
    "e": "The order is: 1) Vision 2) Mission 3) Goals 4) Objectives — from broad to specific."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "'Networking — peers' is listed under which step of starting a business?",
    "o": [
      "Step 5 — License",
      "Step 10 — CSR",
      "Step 11 — Networking",
      "Step 7 — Business Location"
    ],
    "a": 2,
    "e": "Networking — peers is Step 11 in the procedures for starting a small business in Pakistan."
  },
  {
    "c": "PESTLE Analysis",
    "q": "Technology in entrepreneurship is primarily used for:",
    "o": [
      "Increasing product prices",
      "Reducing errors",
      "Attracting government contracts",
      "Avoiding legal hurdles"
    ],
    "a": 1,
    "e": "Technology = to reduce errors in business operations."
  },
  {
    "c": "Finance & Pricing",
    "q": "Which of the following is not a common pricing strategy?",
    "o": [
      "Cost-plus pricing",
      "Penetration pricing",
      "Market skimming",
      "Cash flow pricing"
    ],
    "a": 3,
    "e": "Correct answer: Cash flow pricing."
  },
  {
    "c": "Finance & Pricing",
    "q": "Penetration pricing is used when a company wants to:",
    "o": [
      "Charge high prices initially",
      "Enter the market quickly with low prices",
      "Maximize short-term profits",
      "Avoid competition"
    ],
    "a": 1,
    "e": "Correct answer: Enter the market quickly with low prices."
  },
  {
    "c": "Finance & Pricing",
    "q": "Cost-plus pricing involves:",
    "o": [
      "Setting price below cost",
      "Adding a fixed profit margin to the cost",
      "Ignoring production cost",
      "Pricing based on competitors only"
    ],
    "a": 1,
    "e": "Correct answer: Adding a fixed profit margin to the cost."
  },
  {
    "c": "Finance & Pricing",
    "q": "Which is a risk of offering credit to customers?",
    "o": [
      "Increased sales",
      "Delayed cash inflows",
      "Customer loyalty",
      "Higher market share"
    ],
    "a": 1,
    "e": "Correct answer: Delayed cash inflows."
  },
  {
    "c": "Finance & Pricing",
    "q": "Dynamic pricing means:",
    "o": [
      "Prices are fixed permanently",
      "Prices fluctuate based on demand and market conditions",
      "Prices only follow competitors",
      "Prices are always lower than cost"
    ],
    "a": 1,
    "e": "Correct answer: Prices fluctuate based on demand and market conditions."
  },
  {
    "c": "Finance & Pricing",
    "q": "Trade credit is:",
    "o": [
      "A loan from a bank",
      "Credit extended by suppliers to businesses",
      "Personal credit card debt",
      "Government loan"
    ],
    "a": 1,
    "e": "Correct answer: Credit extended by suppliers to businesses."
  },
  {
    "c": "Finance & Pricing",
    "q": "Price skimming strategy is suitable for:",
    "o": [
      "Highly competitive markets",
      "New innovative products",
      "Commodities",
      "Low-cost items"
    ],
    "a": 1,
    "e": "Correct answer: New innovative products."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "Offering early payment discounts is an example of:",
    "o": [
      "Pricing strategy",
      "Credit strategy",
      "Marketing strategy",
      "Inventory strategy"
    ],
    "a": 1,
    "e": "Correct answer: Credit strategy."
  },
  {
    "c": "Finance & Pricing",
    "q": "Which factor does not affect pricing decisions?",
    "o": [
      "Production cost",
      "Customer demand",
      "Employee salaries",
      "Competitor pricing"
    ],
    "a": 2,
    "e": "Correct answer: Employee salaries."
  },
  {
    "c": "Finance & Pricing",
    "q": "Psychological pricing involves:",
    "o": [
      "Setting prices to seem cheaper, e.g., $9.99",
      "Ignoring cost and demand",
      "Charging extra for luxury",
      "Offering only credit"
    ],
    "a": 0,
    "e": "Correct answer: Setting prices to seem cheaper, e.g., $9.99."
  },
  {
    "c": "Finance & Pricing",
    "q": "A financial plan helps in:",
    "o": [
      "Tracking inventory",
      "Forecasting revenue and expenses",
      "Hiring employees",
      "Marketing strategy"
    ],
    "a": 1,
    "e": "Correct answer: Forecasting revenue and expenses."
  },
  {
    "c": "Finance & Pricing",
    "q": "Which of these is a component of a financial plan?",
    "o": [
      "Mission statement",
      "Cash flow projection",
      "Team building",
      "Branding"
    ],
    "a": 1,
    "e": "Correct answer: Cash flow projection."
  },
  {
    "c": "Finance & Pricing",
    "q": "Break-even analysis determines:",
    "o": [
      "Profit after taxes",
      "When total revenue equals total cost",
      "Maximum sales",
      "Market share"
    ],
    "a": 1,
    "e": "Correct answer: When total revenue equals total cost."
  },
  {
    "c": "Finance & Pricing",
    "q": "Which is not included in a financial plan?",
    "o": [
      "Income statement",
      "Marketing plan",
      "Balance sheet",
      "Cash flow statement"
    ],
    "a": 1,
    "e": "Correct answer: Marketing plan."
  },
  {
    "c": "Finance & Pricing",
    "q": "Forecasting expected sales is important because:",
    "o": [
      "It reduces employee turnover",
      "It helps estimate revenue and plan expenses",
      "It improves customer service",
      "It increases product quality"
    ],
    "a": 1,
    "e": "Correct answer: It helps estimate revenue and plan expenses."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "A budget is:",
    "o": [
      "A prediction of expenses and income",
      "A list of competitors",
      "A hiring plan",
      "A marketing tool"
    ],
    "a": 0,
    "e": "Correct answer: A prediction of expenses and income."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "Financial goals in a plan should be:",
    "o": [
      "Vague and flexible",
      "Specific, measurable, achievable, realistic, time-bound",
      "Only revenue-oriented",
      "Only long-term"
    ],
    "a": 1,
    "e": "Correct answer: Specific, measurable, achievable, realistic, time-bound."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "Which financial statement shows assets, liabilities, and equity?",
    "o": [
      "Income statement",
      "Balance sheet",
      "Cash flow statement",
      "Profit-loss analysis"
    ],
    "a": 1,
    "e": "Correct answer: Balance sheet."
  },
  {
    "c": "Finance & Pricing",
    "q": "A good financial plan helps businesses:",
    "o": [
      "Avoid paying taxes",
      "Make informed investment decisions",
      "Hire only friends",
      "Reduce innovation"
    ],
    "a": 1,
    "e": "Correct answer: Make informed investment decisions."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "When a business plans for contingencies, it is addressing:",
    "o": [
      "Employee schedules",
      "Unexpected financial risks",
      "Marketing campaigns",
      "Customer satisfaction"
    ],
    "a": 1,
    "e": "Correct answer: Unexpected financial risks."
  },
  {
    "c": "Finance & Pricing",
    "q": "Cash flow refers to:",
    "o": [
      "Total sales",
      "Inflows and outflows of cash",
      "Profit only",
      "Employee salaries"
    ],
    "a": 1,
    "e": "Correct answer: Inflows and outflows of cash."
  },
  {
    "c": "Finance & Pricing",
    "q": "Negative cash flow occurs when:",
    "o": [
      "Inflows exceed outflows",
      "Outflows exceed inflows",
      "Revenue is high",
      "Profits are increasing"
    ],
    "a": 1,
    "e": "Correct answer: Outflows exceed inflows."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "Accounts receivable management helps in:",
    "o": [
      "Reducing taxes",
      "Collecting cash from customers promptly",
      "Hiring employees",
      "Reducing production costs"
    ],
    "a": 1,
    "e": "Correct answer: Collecting cash from customers promptly."
  },
  {
    "c": "Finance & Pricing",
    "q": "Which is a way to improve cash flow?",
    "o": [
      "Delay payments to suppliers",
      "Increase unnecessary expenses",
      "Avoid customer credit",
      "Hire more staff"
    ],
    "a": 0,
    "e": "Correct answer: Delay payments to suppliers."
  },
  {
    "c": "Finance & Pricing",
    "q": "Cash flow forecast is used to:",
    "o": [
      "Predict future cash needs",
      "Determine marketing campaigns",
      "Hire employees",
      "Choose suppliers"
    ],
    "a": 0,
    "e": "Correct answer: Predict future cash needs."
  },
  {
    "c": "Finance & Pricing",
    "q": "Operating cash flow excludes:",
    "o": [
      "Revenue from sales",
      "Daily operating expenses",
      "Loan proceeds",
      "Employee salaries"
    ],
    "a": 2,
    "e": "Correct answer: Loan proceeds."
  },
  {
    "c": "Finance & Pricing",
    "q": "The main purpose of cash flow management is to:",
    "o": [
      "Maximize profits only",
      "Ensure the business can meet short-term obligations",
      "Avoid marketing",
      "Increase stock prices"
    ],
    "a": 1,
    "e": "Correct answer: Ensure the business can meet short-term obligations."
  },
  {
    "c": "Finance & Pricing",
    "q": "Which is not a cash flow activity?",
    "o": [
      "Paying supplier invoices",
      "Selling products",
      "Issuing stock",
      "Paying salaries"
    ],
    "a": 2,
    "e": "Correct answer: Issuing stock."
  },
  {
    "c": "Finance & Pricing",
    "q": "A business with consistent positive cash flow can:",
    "o": [
      "Invest in growth",
      "Ignore planning",
      "Stop selling",
      "Reduce marketing"
    ],
    "a": 0,
    "e": "Correct answer: Invest in growth."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "Short-term cash shortages can be solved by:",
    "o": [
      "Increasing sales quickly",
      "Using credit lines or loans",
      "Ignoring payments",
      "Selling long-term assets only"
    ],
    "a": 1,
    "e": "Correct answer: Using credit lines or loans."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "The first step in building a venture team is:",
    "o": [
      "Hiring only family members",
      "Identifying required skills and roles",
      "Marketing products",
      "Securing funding"
    ],
    "a": 1,
    "e": "Correct answer: Identifying required skills and roles."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "A balanced team should have:",
    "o": [
      "Only technical experts",
      "Skills in technical, managerial, and marketing areas",
      "Only investors",
      "Only salespeople"
    ],
    "a": 1,
    "e": "Correct answer: Skills in technical, managerial, and marketing areas."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "Equity sharing in a startup helps:",
    "o": [
      "Avoid taxes",
      "Motivate team members",
      "Increase product cost",
      "Delay funding"
    ],
    "a": 1,
    "e": "Correct answer: Motivate team members."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "Leadership in a venture team is important because:",
    "o": [
      "It reduces cash flow problems",
      "It aligns team goals and efforts",
      "It sets product prices",
      "It avoids innovation"
    ],
    "a": 1,
    "e": "Correct answer: It aligns team goals and efforts."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "Planning for the next generation of leadership ensures:",
    "o": [
      "Immediate profits",
      "Long-term sustainability",
      "Avoids taxes",
      "Reduces innovation"
    ],
    "a": 1,
    "e": "Correct answer: Long-term sustainability."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "Mentorship in a startup helps:",
    "o": [
      "Only investors",
      "Guide and train new team members",
      "Increase competition",
      "Reduce sales"
    ],
    "a": 1,
    "e": "Correct answer: Guide and train new team members."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "Team diversity is important because:",
    "o": [
      "It increases conflict",
      "It brings varied perspectives and skills",
      "It avoids planning",
      "It reduces innovation"
    ],
    "a": 1,
    "e": "Correct answer: It brings varied perspectives and skills."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "Which is not part of team-building?",
    "o": [
      "Recruiting the right talent",
      "Establishing a positive culture",
      "Pricing strategies",
      "Assigning roles"
    ],
    "a": 2,
    "e": "Correct answer: Pricing strategies."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "Succession planning is primarily about:",
    "o": [
      "Hiring temporary staff",
      "Preparing future leaders",
      "Increasing sales",
      "Marketing"
    ],
    "a": 1,
    "e": "Correct answer: Preparing future leaders."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "Effective communication in a team ensures:",
    "o": [
      "Misunderstandings",
      "Efficient coordination and productivity",
      "Reduced innovation",
      "Lower profits"
    ],
    "a": 1,
    "e": "Correct answer: Efficient coordination and productivity."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "Innovation in a small business refers to:",
    "o": [
      "Copying competitors",
      "Introducing new products, processes, or ideas",
      "Reducing expenses only",
      "Hiring more staff"
    ],
    "a": 1,
    "e": "Correct answer: Introducing new products, processes, or ideas."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "Which is essential for fostering innovation?",
    "o": [
      "Strict hierarchy",
      "Open culture that encourages ideas",
      "Avoiding risks",
      "Reducing customer feedback"
    ],
    "a": 1,
    "e": "Correct answer: Open culture that encourages ideas."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "Incremental innovation means:",
    "o": [
      "Major disruptive changes",
      "Small improvements to existing products",
      "Copying others",
      "Reducing quality"
    ],
    "a": 1,
    "e": "Correct answer: Small improvements to existing products."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "Disruptive innovation can:",
    "o": [
      "Replace old products or markets",
      "Only affect employees",
      "Avoid customer needs",
      "Reduce profits always"
    ],
    "a": 0,
    "e": "Correct answer: Replace old products or markets."
  },
  {
    "c": "Entrepreneurship Practice",
    "q": "Encouraging employee creativity leads to:",
    "o": [
      "New ideas and solutions",
      "More bureaucracy",
      "Reduced sales",
      "Higher taxes"
    ],
    "a": 0,
    "e": "Correct answer: New ideas and solutions."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "Innovation can help a small business:",
    "o": [
      "Compete effectively",
      "Avoid taxes",
      "Ignore market trends",
      "Reduce staff"
    ],
    "a": 0,
    "e": "Correct answer: Compete effectively."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "Which is not a barrier to innovation?",
    "o": [
      "Lack of funding",
      "Resistance to change",
      "Customer feedback",
      "Poor management"
    ],
    "a": 2,
    "e": "Correct answer: Customer feedback."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "Collaborating with external partners can:",
    "o": [
      "Reduce innovation",
      "Bring new ideas and resources",
      "Increase bureaucracy only",
      "Avoid market research"
    ],
    "a": 1,
    "e": "Correct answer: Bring new ideas and resources."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "Measuring innovation success involves:",
    "o": [
      "Only profits",
      "Tracking new products, processes, or market impact",
      "Ignoring customer feedback",
      "Reducing investment"
    ],
    "a": 1,
    "e": "Correct answer: Tracking new products, processes, or market impact."
  },
  {
    "c": "Entrepreneurship Concepts",
    "q": "Small businesses innovate effectively when they:",
    "o": [
      "Take calculated risks and learn from failures",
      "Avoid changes",
      "Follow only competitors",
      "Ignore customer needs"
    ],
    "a": 0,
    "e": "Correct answer: Take calculated risks and learn from failures."
  }
];
