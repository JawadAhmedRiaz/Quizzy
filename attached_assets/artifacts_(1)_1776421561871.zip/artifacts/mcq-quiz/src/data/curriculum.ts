import { ENTREPRENEURSHIP_Q } from "./entrepreneurship";
import { ALL_Q, type Question } from "./questions";

export interface ExamSlot {
  id: string;
  label: string;
  available: boolean;
}

export interface Subject {
  id: string;
  name: string;
  icon: string;
  color: string;
  gradient: string;
  exams: ExamSlot[];
}

export interface Semester {
  sem: number;
  subjects: Subject[];
}

export const CURRICULUM: Semester[] = [
  {
    sem: 1,
    subjects: [
      {
        id: "ict",
        name: "ICT",
        icon: "💻",
        color: "#3b82f6",
        gradient: "linear-gradient(135deg, #1d4ed8, #3b82f6)",
        exams: [
          { id: "sem1-ict-midterm", label: "Midterm Exams", available: true },
          { id: "sem1-ict-final", label: "Final Exams", available: false },
          { id: "sem1-ict-general", label: "General Quiz", available: false },
        ],
      },
      {
        id: "entrepreneurship",
        name: "Entrepreneurship",
        icon: "💡",
        color: "#f59e0b",
        gradient: "linear-gradient(135deg, #b45309, #f59e0b)",
        exams: [
          { id: "sem1-entre-midterm", label: "Midterm Exams", available: true },
          { id: "sem1-entre-final", label: "Final Exams", available: false },
          { id: "sem1-entre-general", label: "General Quiz", available: false },
        ],
      },
      {
        id: "quantitative-reasoning",
        name: "Quantitative Reasoning",
        icon: "📊",
        color: "#10b981",
        gradient: "linear-gradient(135deg, #047857, #10b981)",
        exams: [
          { id: "sem1-qr-midterm", label: "Midterm Exams", available: false },
          { id: "sem1-qr-final", label: "Final Exams", available: false },
          { id: "sem1-qr-general", label: "General Quiz", available: false },
        ],
      },
      {
        id: "civics",
        name: "Civics & Community",
        icon: "🏛️",
        color: "#8b5cf6",
        gradient: "linear-gradient(135deg, #6d28d9, #8b5cf6)",
        exams: [
          { id: "sem1-civics-midterm", label: "Midterm Exams", available: false },
          { id: "sem1-civics-final", label: "Final Exams", available: false },
          { id: "sem1-civics-general", label: "General Quiz", available: false },
        ],
      },
      {
        id: "ideology",
        name: "Ideology & Constitution",
        icon: "⚖️",
        color: "#ef4444",
        gradient: "linear-gradient(135deg, #b91c1c, #ef4444)",
        exams: [
          { id: "sem1-ideology-midterm", label: "Midterm Exams", available: false },
          { id: "sem1-ideology-final", label: "Final Exams", available: false },
          { id: "sem1-ideology-general", label: "General Quiz", available: false },
        ],
      },
      {
        id: "english",
        name: "Functional English",
        icon: "📝",
        color: "#06b6d4",
        gradient: "linear-gradient(135deg, #0e7490, #06b6d4)",
        exams: [
          { id: "sem1-english-midterm", label: "Midterm Exams", available: false },
          { id: "sem1-english-final", label: "Final Exams", available: false },
          { id: "sem1-english-general", label: "General Quiz", available: false },
        ],
      },
    ],
  },
  { sem: 2, subjects: [] },
  { sem: 3, subjects: [] },
  { sem: 4, subjects: [] },
  { sem: 5, subjects: [] },
  { sem: 6, subjects: [] },
  { sem: 7, subjects: [] },
  { sem: 8, subjects: [] },
];

const QUIZ_QUESTION_MAP: Record<string, Question[]> = {
  "sem1-ict-midterm": ALL_Q,
  "sem1-entre-midterm": ENTREPRENEURSHIP_Q,
};

export function getQuizQuestions(quizId: string): Question[] {
  return QUIZ_QUESTION_MAP[quizId] ?? [];
}

export interface QuizMeta {
  quizId: string;
  sem: number;
  subject: string;
  examType: string;
  subjectName: string;
  examLabel: string;
  icon: string;
}

export function getQuizMeta(quizId: string): QuizMeta | null {
  for (const sem of CURRICULUM) {
    for (const subj of sem.subjects) {
      for (const exam of subj.exams) {
        if (exam.id === quizId) {
          const label = exam.label.toLowerCase();
          return {
            quizId,
            sem: sem.sem,
            subject: subj.id,
            examType: label.includes("mid") ? "midterm" : label.includes("final") ? "final" : "general",
            subjectName: subj.name,
            examLabel: exam.label,
            icon: subj.icon,
          };
        }
      }
    }
  }
  return null;
}
