import { useState, useEffect } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Router, Route, Switch } from "wouter";
import { useAuth } from "@workspace/replit-auth-web";
import { QuizProvider } from "@/context/QuizContext";
import { WelcomeModal } from "@/components/WelcomeModal";
import { HomePage } from "@/pages/HomePage";
import { QuizSetupPage } from "@/pages/QuizSetupPage";
import { QuizPage } from "@/pages/QuizPage";
import { ResultPage } from "@/pages/ResultPage";
import { LeaderboardPage } from "@/pages/LeaderboardPage";
import { AnalyticsPage } from "@/pages/AnalyticsPage";

const queryClient = new QueryClient();

function AppInner() {
  const { isAuthenticated, isLoading: authLoading, login } = useAuth();
  const [showWelcome, setShowWelcome] = useState(false);

  useEffect(() => {
    if (authLoading) return;
    if (isAuthenticated) { setShowWelcome(false); return; }
    const dismissed = localStorage.getItem("welcomeDismissed");
    if (!dismissed) setShowWelcome(true);
  }, [authLoading, isAuthenticated]);

  return (
    <>
      <div className="quiz-bg" />
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/quiz/:quizId/setup" component={QuizSetupPage} />
        <Route path="/quiz/:quizId/play" component={QuizPage} />
        <Route path="/quiz/:quizId/result" component={ResultPage} />
        <Route path="/quiz/:quizId/leaderboard" component={LeaderboardPage} />
        <Route path="/analytics" component={AnalyticsPage} />
        <Route component={HomePage} />
      </Switch>
      <WelcomeModal
        show={showWelcome}
        onDismiss={() => { localStorage.setItem("welcomeDismissed", "1"); setShowWelcome(false); }}
        onLogin={login}
      />
    </>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <QuizProvider>
        <Router>
          <AppInner />
        </Router>
      </QuizProvider>
    </QueryClientProvider>
  );
}
