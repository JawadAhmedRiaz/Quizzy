import { motion, AnimatePresence } from "framer-motion";

interface Props {
  show: boolean;
  onDismiss: () => void;
  onLogin: () => void;
}

export function WelcomeModal({ show, onDismiss, onLogin }: Props) {
  return (
    <AnimatePresence>
      {show && (
        <motion.div
          key="welcome-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 z-50 flex items-center justify-center px-4"
          style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(6px)" }}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.92, y: 24 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.92, y: 24 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="w-full max-w-sm rounded-2xl p-6 flex flex-col gap-5"
            style={{
              background: "hsl(220, 25%, 9%)",
              border: "1px solid hsl(var(--border))",
              boxShadow: "0 32px 80px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.04)",
            }}
          >
            <div className="text-center">
              <div className="text-5xl mb-3">🎓</div>
              <h2 className="text-xl font-bold mb-2" style={{ fontFamily: "'Poppins', sans-serif", color: "hsl(var(--foreground))" }}>
                Welcome to Quizzy!
              </h2>
              <p className="text-sm leading-relaxed" style={{ color: "hsl(var(--muted-foreground))" }}>
                Log in with Replit to track your scores on the global leaderboard and{" "}
                <span style={{ color: "#60a5fa", fontWeight: 600 }}>
                  get early access to future quizzes
                </span>{" "}
                as they are added.
              </p>
            </div>

            <div className="flex flex-col gap-2.5">
              <p className="text-xs text-center font-semibold uppercase tracking-widest" style={{ color: "hsl(var(--muted-foreground))", opacity: 0.6 }}>
                Continue with Replit
              </p>
              <button
                onClick={onLogin}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold text-sm transition-all hover:scale-[1.02] active:scale-[0.98]"
                style={{ background: "linear-gradient(135deg, #3b82f6, #6366f1)", color: "#fff", boxShadow: "0 4px 20px rgba(59,130,246,0.35)" }}
              >
                <span className="text-lg">🔐</span>
                <span className="flex-1 text-left">Log in with Replit</span>
                <span style={{ opacity: 0.7 }}>→</span>
              </button>
            </div>

            <button
              onClick={onDismiss}
              className="w-full py-2.5 rounded-xl text-xs font-medium transition-all hover:opacity-80"
              style={{ color: "hsl(var(--muted-foreground))", background: "transparent" }}
            >
              Maybe later — continue without logging in
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
