import { useEffect } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@workspace/replit-auth-web";
import { useGetUserAnalytics, getGetUserAnalyticsQueryKey } from "@workspace/api-client-react";

interface Props {
  open: boolean;
  onClose: () => void;
}

export function Sidebar({ open, onClose }: Props) {
  const [, navigate] = useLocation();
  const { user, isAuthenticated, login, logout } = useAuth();

  const userName = user ? [user.firstName, user.lastName].filter(Boolean).join(" ").trim() : "";

  const { data: analytics } = useGetUserAnalytics(
    { userName },
    { query: { enabled: !!userName, queryKey: getGetUserAnalyticsQueryKey({ userName }) } }
  );

  // Close on Escape
  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [onClose]);

  function goTo(path: string) {
    navigate(path);
    onClose();
  }

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div key="backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-40"
            style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)" }} />

          {/* Panel */}
          <motion.aside key="panel"
            initial={{ x: "-100%" }} animate={{ x: 0 }} exit={{ x: "-100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed left-0 top-0 bottom-0 z-50 w-72 flex flex-col overflow-y-auto"
            style={{ background: "hsl(220, 25%, 8%)", borderRight: "1px solid hsl(var(--border))" }}>

            {/* Close */}
            <div className="flex items-center justify-between px-4 pt-5 pb-4">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🎓</span>
                <span className="font-black text-lg" style={{ fontFamily: "'Poppins', sans-serif", background: "linear-gradient(135deg, #60a5fa, #a78bfa)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Quizzy</span>
              </div>
              <button onClick={onClose} className="p-1.5 rounded-lg hover:opacity-70 transition-all"
                style={{ background: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))" }}>✕</button>
            </div>

            <div className="flex flex-col gap-4 px-4 pb-6">
              {/* ── PROFILE ── */}
              <div className="glow-card p-4">
                <p className="text-xs font-semibold uppercase tracking-wider mb-3" style={{ color: "hsl(var(--muted-foreground))" }}>👤 Profile</p>
                {isAuthenticated && user ? (
                  <div className="flex flex-col gap-3">
                    <div className="flex items-center gap-3">
                      {user.profileImageUrl ? (
                        <img src={user.profileImageUrl} alt="" className="w-10 h-10 rounded-full object-cover" style={{ border: "2px solid rgba(99,102,241,0.5)" }} />
                      ) : (
                        <div className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm"
                          style={{ background: "linear-gradient(135deg, #3b82f6, #6366f1)", color: "#fff" }}>
                          {(user.firstName?.[0] ?? "U").toUpperCase()}
                        </div>
                      )}
                      <div className="min-w-0">
                        <p className="text-sm font-bold truncate">{[user.firstName, user.lastName].filter(Boolean).join(" ")}</p>
                        <p className="text-xs truncate" style={{ color: "hsl(var(--muted-foreground))" }}>{user.email}</p>
                      </div>
                    </div>
                    {analytics && analytics.totalAttempts > 0 ? (
                      <div className="grid grid-cols-3 gap-2">
                        {[
                          { v: analytics.totalAttempts, l: "Attempts", c: "#60a5fa" },
                          { v: `${Math.round(analytics.avgPct)}%`, l: "Avg Score", c: Math.round(analytics.avgPct) >= 60 ? "#34d399" : "#f87171" },
                          { v: analytics.bySubject.length, l: "Subjects", c: "#a78bfa" },
                        ].map(({ v, l, c }) => (
                          <div key={l} className="rounded-xl p-2 text-center" style={{ background: "hsl(var(--muted))" }}>
                            <div className="text-sm font-black" style={{ color: c }}>{v}</div>
                            <div className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>{l}</div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>Complete a quiz to see your stats here.</p>
                    )}
                    <button onClick={logout}
                      className="w-full py-2 rounded-lg text-xs font-semibold transition-all hover:opacity-80"
                      style={{ background: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))", border: "1px solid hsl(var(--border))" }}>
                      Log out
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col gap-3">
                    <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>Log in to track your progress and appear on leaderboards.</p>
                    <button onClick={login}
                      className="w-full py-2.5 rounded-xl text-sm font-bold transition-all hover:scale-[1.01]"
                      style={{ background: "linear-gradient(135deg, #3b82f6, #6366f1)", color: "#fff" }}>
                      Log in with Replit
                    </button>
                  </div>
                )}
              </div>

              {/* ── ANALYTICS ── */}
              <div className="glow-card p-4">
                <p className="text-xs font-semibold uppercase tracking-wider mb-3" style={{ color: "hsl(var(--muted-foreground))" }}>📊 Analytics</p>
                <div className="flex flex-col gap-2">
                  <button onClick={() => goTo("/analytics?tab=mine")}
                    className="w-full flex items-center gap-3 p-3 rounded-xl text-sm font-semibold text-left transition-all hover:scale-[1.01]"
                    style={{ background: "rgba(99,102,241,0.12)", color: "#a78bfa", border: "1px solid rgba(99,102,241,0.2)" }}>
                    <span>📈</span>
                    <span className="flex-1">My Performance</span>
                    <span style={{ opacity: 0.6 }}>→</span>
                  </button>
                  <p className="text-xs px-1" style={{ color: "hsl(var(--muted-foreground))" }}>
                    View your scores per semester, subject, and exam type.
                  </p>
                </div>
              </div>

              {/* ── COMPARISON ── */}
              <div className="glow-card p-4">
                <p className="text-xs font-semibold uppercase tracking-wider mb-3" style={{ color: "hsl(var(--muted-foreground))" }}>⚔️ Comparison</p>
                <div className="flex flex-col gap-2">
                  <button onClick={() => goTo("/analytics?tab=compare")}
                    className="w-full flex items-center gap-3 p-3 rounded-xl text-sm font-semibold text-left transition-all hover:scale-[1.01]"
                    style={{ background: "rgba(59,130,246,0.12)", color: "#60a5fa", border: "1px solid rgba(59,130,246,0.2)" }}>
                    <span>📊</span>
                    <span className="flex-1">Compare Students</span>
                    <span style={{ opacity: 0.6 }}>→</span>
                  </button>
                  <p className="text-xs px-1" style={{ color: "hsl(var(--muted-foreground))" }}>
                    Side-by-side comparison of scores, accuracy, and subject performance.
                  </p>
                </div>
              </div>

              {/* Footer */}
              <div className="text-center pt-2">
                <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))", opacity: 0.5 }}>made with ❤️ for welfare of students</p>
              </div>
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
