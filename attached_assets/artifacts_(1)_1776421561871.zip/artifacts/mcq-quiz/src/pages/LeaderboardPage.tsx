import { useParams, useLocation } from "wouter";
import { motion } from "framer-motion";
import { useGetQuizLeaderboard, getGetQuizLeaderboardQueryKey } from "@workspace/api-client-react";
import { getQuizMeta } from "@/data/curriculum";

export function LeaderboardPage() {
  const { quizId } = useParams<{ quizId: string }>();
  const [, navigate] = useLocation();
  const meta = getQuizMeta(quizId!);

  const { data, isLoading } = useGetQuizLeaderboard(
    { quizId: quizId! },
    { query: { queryKey: getGetQuizLeaderboardQueryKey({ quizId: quizId! }) } }
  );

  const medals = ["🥇", "🥈", "🥉"];
  const rankColors = ["#f59e0b", "#9ca3af", "#b45309"];

  return (
    <div className="min-h-screen flex flex-col">
      <div className="flex-1 w-full max-w-xl mx-auto px-4 py-6 flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-black" style={{ fontFamily: "'Poppins', sans-serif" }}>🏆 Leaderboard</h1>
            {meta && <p className="text-xs mt-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Semester {meta.sem} · {meta.subjectName} · {meta.examLabel}</p>}
            <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>Global · All participants · Best scores</p>
          </div>
          <button onClick={() => navigate("/")}
            className="px-4 py-2 rounded-lg text-xs font-semibold hover:scale-[1.02] transition-all"
            style={{ background: "hsl(var(--muted))", border: "1px solid hsl(var(--border))", color: "hsl(var(--foreground))" }}>
            ← Home
          </button>
        </div>

        <div className="glow-card p-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-8 gap-2">
              <div className="w-4 h-4 rounded-full border-2 border-blue-400 border-t-transparent animate-spin" />
              <span className="text-sm" style={{ color: "hsl(var(--muted-foreground))" }}>Loading scores…</span>
            </div>
          ) : !data || data.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-4xl mb-3">📭</div>
              <p className="text-sm" style={{ color: "hsl(var(--muted-foreground))" }}>No scores yet — be the first!</p>
            </div>
          ) : (
            <div className="flex flex-col">
              {data.map((e, i) => (
                <motion.div key={e.userName} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: Math.min(i * 0.04, 0.5) }}
                  className="flex items-center gap-3 py-3"
                  style={{ borderBottom: i < data.length - 1 ? "1px solid hsl(var(--border))" : "none" }}>
                  <span className="text-lg w-8 text-center flex-shrink-0" style={{ color: i < 3 ? rankColors[i] : undefined }}>
                    {i < 3 ? medals[i] : `#${i + 1}`}
                  </span>
                  <span className="flex-1 text-sm font-semibold truncate">{e.userName}</span>
                  <span className="text-xs px-2 py-0.5 rounded-full flex-shrink-0"
                    style={{ background: "rgba(59,130,246,0.15)", color: "#60a5fa" }}>{e.bestPct}%</span>
                  <span className="text-sm font-black flex-shrink-0" style={{ color: i < 3 ? rankColors[i] : "#60a5fa" }}>{e.bestScore} pts</span>
                  <span className="text-xs flex-shrink-0" style={{ color: "hsl(var(--muted-foreground))" }}>{e.correct}/{e.total}</span>
                  <span className="text-xs px-1.5 py-0.5 rounded-md flex-shrink-0"
                    style={{ background: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))" }}>×{e.attempts}</span>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        {meta && (
          <button onClick={() => navigate(`/quiz/${quizId}/setup`)}
            className="w-full py-3 rounded-xl font-bold text-sm hover:scale-[1.02] transition-all"
            style={{ background: "linear-gradient(135deg, #3b82f6, #6366f1)", color: "#fff", boxShadow: "0 4px 16px rgba(59,130,246,0.3)" }}>
            Take This Quiz →
          </button>
        )}
      </div>
    </div>
  );
}
