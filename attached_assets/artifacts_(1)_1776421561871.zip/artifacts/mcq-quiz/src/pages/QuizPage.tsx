import { useState, useEffect, useRef } from "react";
import { useParams, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useQuiz, type QuizAnswer } from "@/context/QuizContext";
import { getQuizMeta, getQuizQuestions } from "@/data/curriculum";
import type { Question } from "@/data/questions";

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const LABELS = ["A", "B", "C", "D"];
const DIFFICULTY_SECONDS = {
  easy: 30,
  medium: 15,
  hard: 10,
};

interface HistoryEntry {
  mode: "main" | "backlog";
  idx: number;
  wasBacklogAdded: boolean;
}

export function QuizPage() {
  const { quizId } = useParams<{ quizId: string }>();
  const [, navigate] = useLocation();
  const { totalToAttempt, session, difficulty, playerName, finalizeSession } = useQuiz();
  const meta = getQuizMeta(quizId!);
  const perQuestionSeconds = DIFFICULTY_SECONDS[difficulty];
  const attemptCount = session?.totalToAttempt ?? totalToAttempt;

  // Refs for stale-closure-safe access in timer/callbacks
  const mainQueueRef = useRef<Question[]>([]);
  const backlogRef = useRef<Question[]>([]);
  const modeRef = useRef<"main" | "backlog">("main");
  const idxRef = useRef(0);
  const answersRef = useRef<QuizAnswer[]>([]);
  const historyRef = useRef<HistoryEntry[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const shuffleCache = useRef(new Map<string, { o: string; i: number }[]>());

  // React state for rendering
  const [mainQueue, setMainQueue] = useState<Question[]>([]);
  const [backlog, setBacklog] = useState<Question[]>([]);
  const [mode, setMode] = useState<"main" | "backlog">("main");
  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState<QuizAnswer[]>([]);
  const [answered, setAnswered] = useState(false);
  const [selectedOptIdx, setSelectedOptIdx] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState(perQuestionSeconds);
  const [shuffledOpts, setShuffledOpts] = useState<{ o: string; i: number }[]>([]);
  const [showExpl, setShowExpl] = useState(false);
  const [finished, setFinished] = useState(false);
  const [canGoBack, setCanGoBack] = useState(false);

  // Init
  useEffect(() => {
    const qs = getQuizQuestions(quizId!);
    const ordered = shuffle(qs);
    const selected = ordered.slice(0, Math.min(attemptCount, qs.length));
    mainQueueRef.current = selected;
    setMainQueue(selected);
  }, []);

  const currentQ = mode === "main" ? mainQueue[idx] : backlog[idx];
  const questionKey = currentQ ? `${mode}-${idx}-${currentQ.q.slice(0, 15)}` : null;

  // On question change: reset UI, load/cache shuffled opts, start timer
  useEffect(() => {
    if (!currentQ || !questionKey) return;
    setAnswered(false);
    setSelectedOptIdx(null);
    setShowExpl(false);

    if (!shuffleCache.current.has(questionKey)) {
      shuffleCache.current.set(questionKey, shuffle(currentQ.o.map((o, i) => ({ o, i }))));
    }
    setShuffledOpts(shuffleCache.current.get(questionKey)!);
    setTimeLeft(perQuestionSeconds);

    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          doSkip();
          return 0;
        }
        return t - 1;
      });
    }, 1000);

    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [questionKey]);

  // Navigate on finish
  useEffect(() => {
    if (!finished) return;
    const score = answersRef.current.reduce((s, a) => s + a.pointsEarned, 0);
    const correct = answersRef.current.filter((a) => a.isCorrect).length;
    finalizeSession(answersRef.current, score, correct);
    navigate(`/quiz/${quizId}/result`);
  }, [finished]);

  function addAnswer(ans: QuizAnswer) {
    answersRef.current = [...answersRef.current, ans];
    setAnswers([...answersRef.current]);
    setCanGoBack(true);
  }

  function pushHistory(wasBacklogAdded = false) {
    historyRef.current.push({ mode: modeRef.current, idx: idxRef.current, wasBacklogAdded });
  }

  function advanceQueue(newBacklog?: Question[]) {
    const bl = newBacklog ?? backlogRef.current;
    if (modeRef.current === "main") {
      const next = idxRef.current + 1;
      if (next < mainQueueRef.current.length) {
        idxRef.current = next; setIdx(next);
      } else if (bl.length > 0) {
        modeRef.current = "backlog"; idxRef.current = 0;
        setMode("backlog"); setIdx(0);
      } else {
        setFinished(true);
      }
    } else {
      const next = idxRef.current + 1;
      if (next < bl.length) {
        idxRef.current = next; setIdx(next);
      } else {
        setFinished(true);
      }
    }
  }

  function doSkip() {
    if (timerRef.current) clearInterval(timerRef.current);
    const q = modeRef.current === "main"
      ? mainQueueRef.current[idxRef.current]
      : backlogRef.current[idxRef.current];
    if (!q) return;

    let wasBacklogAdded = false;
    let newBacklog = backlogRef.current;
    if (modeRef.current === "main") {
      newBacklog = [...backlogRef.current, q];
      backlogRef.current = newBacklog;
      setBacklog([...newBacklog]);
      wasBacklogAdded = true;
    }

    pushHistory(wasBacklogAdded);
    addAnswer({ question: q, selectedOptionIndex: null, isCorrect: false, skipped: true, pointsEarned: 0 });
    advanceQueue(newBacklog);
  }

  function handleAnswer(optIdx: number) {
    if (answered || !currentQ) return;
    if (timerRef.current) clearInterval(timerRef.current);
    const isCorrect = optIdx === currentQ.a;
    const pts = isCorrect ? Math.max(5, Math.round(10 * (timeLeft / perQuestionSeconds))) : 0;
    setSelectedOptIdx(optIdx);
    setAnswered(true);
    setShowExpl(true);
    pushHistory(false);
    addAnswer({ question: currentQ, selectedOptionIndex: optIdx, isCorrect, skipped: false, pointsEarned: pts });
  }

  function handleNext() {
    advanceQueue();
  }

  function handleBack() {
    const prev = historyRef.current.pop();
    if (!prev) return;
    if (timerRef.current) clearInterval(timerRef.current);

    // Remove last answer
    answersRef.current = answersRef.current.slice(0, -1);
    setAnswers([...answersRef.current]);
    setCanGoBack(historyRef.current.length > 0);

    // If skip added to backlog, remove that entry
    if (prev.wasBacklogAdded) {
      backlogRef.current = backlogRef.current.slice(0, -1);
      setBacklog([...backlogRef.current]);
    }

    // Restore position
    modeRef.current = prev.mode;
    idxRef.current = prev.idx;
    setMode(prev.mode);
    setIdx(prev.idx);
  }

  const totalQ = mainQueue.length;
  const doneCount = answers.length;
  const progressPct = totalQ > 0 ? (doneCount / totalQ) * 100 : 0;
  const timerPct = (timeLeft / perQuestionSeconds) * 100;
  const timerColor = timeLeft > perQuestionSeconds * 0.5 ? "#22c55e" : timeLeft > perQuestionSeconds * 0.25 ? "#f59e0b" : "#ef4444";
  const isLastQuestion =
    (mode === "main" && idx + 1 >= totalQ && backlog.length === 0) ||
    (mode === "backlog" && idx + 1 >= backlog.length);

  if (!currentQ || mainQueue.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-6 h-6 rounded-full border-2 border-blue-400 border-t-transparent animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <div className="flex-1 w-full max-w-xl mx-auto px-4 py-6 flex flex-col gap-4">
        {/* Top bar */}
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-medium truncate" style={{ color: "hsl(var(--muted-foreground))" }}>
              {meta?.subjectName} · Q {doneCount + 1}/{totalQ}
            </p>
            {mode === "backlog" && (
              <p className="text-xs font-semibold" style={{ color: "#fbbf24" }}>
                ⏭ Reviewing {backlog.length - idx} skipped
              </p>
            )}
          </div>
          {/* Timer */}
          <div className="relative flex items-center justify-center flex-shrink-0">
            <svg width="52" height="52" className={timeLeft <= 5 ? "timer-danger" : ""}>
              <circle cx="26" cy="26" r="22" fill="none" stroke="hsl(var(--muted))" strokeWidth="3" />
              <circle cx="26" cy="26" r="22" fill="none" stroke={timerColor} strokeWidth="3" strokeLinecap="round"
                strokeDasharray={`${2 * Math.PI * 22}`}
                strokeDashoffset={`${2 * Math.PI * 22 * (1 - timerPct / 100)}`}
                transform="rotate(-90 26 26)"
                style={{ transition: "stroke-dashoffset 1s linear, stroke 0.5s" }} />
            </svg>
            <span className="absolute text-xs font-bold" style={{ color: timerColor }}>{timeLeft}s</span>
          </div>
          <span className="text-sm font-black flex-shrink-0" style={{ color: "#60a5fa" }}>
            {answers.reduce((s, a) => s + a.pointsEarned, 0)} pts
          </span>
        </div>

        {/* Progress bar */}
        <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "hsl(var(--muted))" }}>
          <motion.div className="h-full rounded-full"
            style={{ background: "linear-gradient(90deg, #3b82f6, #6366f1)" }}
            animate={{ width: `${progressPct}%` }} transition={{ duration: 0.4 }} />
        </div>

        {/* Question card */}
        <AnimatePresence mode="wait">
          <motion.div key={questionKey} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.22 }} className="glow-card p-5 flex flex-col gap-4">
            <div className="flex items-start justify-between gap-2">
              <p className="text-base font-semibold leading-relaxed flex-1">{currentQ.q}</p>
              <span className="flex-shrink-0 text-xs px-2 py-1 rounded-full font-semibold"
                style={{ background: "rgba(99,102,241,0.15)", color: "#a78bfa", border: "1px solid rgba(99,102,241,0.2)", whiteSpace: "nowrap" }}>
                {currentQ.c}
              </span>
            </div>
            <div className="flex flex-col gap-2">
              {shuffledOpts.map(({ o, i }, pos) => {
                const isSelected = selectedOptIdx === i;
                const isCorrect = i === currentQ.a;
                let style: React.CSSProperties = {
                  background: "hsl(var(--muted))",
                  border: "1px solid hsl(var(--border))",
                  color: "hsl(var(--foreground))",
                };
                if (answered) {
                  if (isCorrect) style = { background: "rgba(16,185,129,0.15)", border: "1px solid rgba(16,185,129,0.5)", color: "#34d399" };
                  else if (isSelected) style = { background: "rgba(239,68,68,0.15)", border: "1px solid rgba(239,68,68,0.5)", color: "#f87171" };
                  else style = { background: "hsl(var(--muted))", border: "1px solid hsl(var(--border))", color: "hsl(var(--muted-foreground))", opacity: 0.5 };
                }
                return (
                  <button key={`${questionKey}-${pos}`} onClick={() => handleAnswer(i)} disabled={answered}
                    className="w-full text-left px-4 py-3 rounded-xl text-sm font-medium transition-all leading-relaxed"
                    style={{ ...style, cursor: answered ? "default" : "pointer" }}
                    onMouseEnter={(e) => { if (!answered) { e.currentTarget.style.background = "hsl(var(--secondary))"; e.currentTarget.style.borderColor = "#6366f1"; } }}
                    onMouseLeave={(e) => { if (!answered) { e.currentTarget.style.background = "hsl(var(--muted))"; e.currentTarget.style.borderColor = "hsl(var(--border))"; } }}>
                    <span className="flex items-start gap-3">
                      <span className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5"
                        style={{ background: answered && isCorrect ? "rgba(16,185,129,0.3)" : "rgba(255,255,255,0.08)" }}>
                        {LABELS[pos]}
                      </span>
                      {o}
                    </span>
                  </button>
                );
              })}
            </div>

            <AnimatePresence>
              {showExpl && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
                  className="rounded-xl p-3 text-xs leading-relaxed overflow-hidden"
                  style={{ background: "rgba(59,130,246,0.08)", borderLeft: "3px solid #3b82f6", color: "hsl(var(--muted-foreground))" }}>
                  💡 {currentQ.e}
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </AnimatePresence>

        {/* Action buttons */}
        <div className="flex justify-between items-center gap-2">
          <button onClick={handleBack} disabled={!canGoBack}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all"
            style={{
              background: canGoBack ? "rgba(251,191,36,0.12)" : "hsl(var(--muted))",
              color: canGoBack ? "#fbbf24" : "hsl(var(--muted-foreground))",
              border: `1px solid ${canGoBack ? "rgba(251,191,36,0.3)" : "hsl(var(--border))"}`,
              opacity: canGoBack ? 1 : 0.4, cursor: canGoBack ? "pointer" : "not-allowed",
            }}>
            ↩ Back
          </button>

          <div className="flex gap-2">
            {!answered && (
              <button onClick={doSkip}
                className="px-5 py-2.5 rounded-xl text-sm font-semibold transition-all hover:scale-[1.02]"
                style={{ background: "rgba(239,68,68,0.12)", color: "#f87171", border: "1px solid rgba(239,68,68,0.3)" }}>
                Skip ⏭
              </button>
            )}
            {answered && (
              <button onClick={handleNext}
                className="px-6 py-2.5 rounded-xl text-sm font-bold transition-all hover:scale-[1.02]"
                style={{ background: "linear-gradient(135deg, #3b82f6, #6366f1)", color: "#fff", boxShadow: "0 4px 16px rgba(59,130,246,0.3)" }}>
                {isLastQuestion ? "See Results 🏆" : "Next →"}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
