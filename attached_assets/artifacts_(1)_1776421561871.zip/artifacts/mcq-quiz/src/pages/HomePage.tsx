import { useState } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@workspace/replit-auth-web";
import { CURRICULUM, type Subject } from "@/data/curriculum";
import { Sidebar } from "@/components/Sidebar";

const ORDINALS = ["1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th"];

export function HomePage() {
  const [, navigate] = useLocation();
  const { user, isAuthenticated, isLoading } = useAuth();
  const [selectedSem, setSelectedSem] = useState(1);
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const currentSem = CURRICULUM.find((s) => s.sem === selectedSem)!;

  return (
    <div className="min-h-screen flex flex-col">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      {/* Header */}
      <header className="w-full px-4 pt-6 pb-4 flex items-center gap-3 relative">
        {/* Sidebar toggle */}
        <button onClick={() => setSidebarOpen(true)}
          className="flex-shrink-0 p-2.5 rounded-xl transition-all hover:scale-[1.05]"
          style={{ background: "hsl(var(--muted))", border: "1px solid hsl(var(--border))" }}>
          <div className="flex flex-col gap-1 w-4">
            <span className="block h-0.5 rounded-full" style={{ background: "hsl(var(--foreground))" }} />
            <span className="block h-0.5 rounded-full w-3" style={{ background: "hsl(var(--foreground))" }} />
            <span className="block h-0.5 rounded-full" style={{ background: "hsl(var(--foreground))" }} />
          </div>
        </button>

        {/* Branding */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🎓</span>
            <h1 className="text-2xl font-black" style={{ fontFamily: "'Poppins', sans-serif", background: "linear-gradient(135deg, #60a5fa, #a78bfa)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
              Quizzy
            </h1>
          </div>
          <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>Your Personal Learning Management System</p>
        </div>

        {/* Right: auth + analytics */}
        {!isLoading && (
          <div className="flex items-center gap-2 flex-shrink-0">
            <button onClick={() => navigate("/analytics?tab=mine")}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all hover:scale-[1.02]"
              style={{ background: "rgba(99,102,241,0.15)", color: "#a78bfa", border: "1px solid rgba(99,102,241,0.3)" }}>
              📊
            </button>
            {isAuthenticated && user?.profileImageUrl ? (
              <img src={user.profileImageUrl} alt="" className="w-8 h-8 rounded-full object-cover cursor-pointer"
                style={{ border: "2px solid rgba(99,102,241,0.5)" }}
                onClick={() => setSidebarOpen(true)} />
            ) : null}
          </div>
        )}
      </header>

      {/* Subtitle */}
      <div className="px-4 pb-3 text-center">
        <p className="text-xs font-medium" style={{ color: "#a78bfa" }}>by Hamid Mukhtar</p>
      </div>

      {/* Semester Selector */}
      <div className="px-4 mb-3">
        <p className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: "hsl(var(--muted-foreground))" }}>Select Semester</p>
        <select
          value={selectedSem}
          onChange={(e) => { setSelectedSem(Number(e.target.value)); setSelectedSubject(null); }}
          className="w-full px-4 py-3 rounded-xl text-sm font-bold outline-none"
          style={{ background: "hsl(var(--muted))", border: "1px solid hsl(var(--border))", color: "hsl(var(--foreground))" }}
        >
          {CURRICULUM.map((s) => (
            <option key={s.sem} value={s.sem}>
              Semester {s.sem} ({ORDINALS[s.sem - 1]}){s.subjects.length === 0 ? " — No Data Available" : ""}
            </option>
          ))}
        </select>
      </div>

      {/* Content area */}
      <div className="flex-1 w-full max-w-2xl mx-auto px-4 pb-6">
        <AnimatePresence mode="wait">
          {!selectedSubject ? (
            <motion.div key={`sem-${selectedSem}`} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }} transition={{ duration: 0.22 }}>
              {currentSem.subjects.length === 0 ? (
                <div className="glow-card p-10 text-center">
                  <div className="text-5xl mb-3">📭</div>
                  <p className="text-base font-semibold mb-1">No Data Available</p>
                  <p className="text-sm" style={{ color: "hsl(var(--muted-foreground))" }}>
                    Content for {ORDINALS[selectedSem - 1]} Semester will be added soon.
                  </p>
                </div>
              ) : (
                <>
                  <p className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: "hsl(var(--muted-foreground))" }}>
                    {ORDINALS[selectedSem - 1]} Semester — {currentSem.subjects.length} Subjects
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    {currentSem.subjects.map((subj, i) => (
                      <motion.button key={subj.id}
                        initial={{ opacity: 0, scale: 0.94 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.05 }}
                        onClick={() => setSelectedSubject(subj)}
                        className="glow-card p-5 text-left flex flex-col gap-3 hover:scale-[1.02] transition-all active:scale-[0.98]"
                        style={{ cursor: "pointer" }}>
                        <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl" style={{ background: subj.gradient }}>
                          {subj.icon}
                        </div>
                        <div>
                          <p className="text-sm font-bold leading-tight">{subj.name}</p>
                          <p className="text-xs mt-1 font-semibold" style={{ color: subj.color }}>Explore →</p>
                        </div>
                      </motion.button>
                    ))}
                  </div>
                </>
              )}
            </motion.div>
          ) : (
            <motion.div key={`subj-${selectedSubject.id}`} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }} transition={{ duration: 0.22 }}>
              {/* Subject header */}
              <div className="flex items-center gap-3 mb-4">
                <button onClick={() => setSelectedSubject(null)}
                  className="p-2 rounded-lg transition-all hover:scale-[1.02]"
                  style={{ background: "hsl(var(--muted))", border: "1px solid hsl(var(--border))" }}>
                  ← Back
                </button>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl" style={{ background: selectedSubject.gradient }}>
                  {selectedSubject.icon}
                </div>
                <div>
                  <p className="font-bold">{selectedSubject.name}</p>
                  <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>{ORDINALS[selectedSem - 1]} Semester</p>
                </div>
              </div>

              {/* Exam type selector */}
              <p className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: "hsl(var(--muted-foreground))" }}>Exam Type</p>
              <div className="flex flex-col gap-3">
                {selectedSubject.exams.map((exam, i) => (
                  <motion.div key={exam.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.07 }}
                    className="glow-card p-4 flex items-center gap-4"
                    style={{ opacity: exam.available ? 1 : 0.6 }}>
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0"
                      style={{ background: exam.available ? selectedSubject.gradient : "hsl(var(--muted))" }}>
                      {exam.available ? "📚" : "🔒"}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold">{exam.label}</p>
                      <p className="text-xs mt-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>
                        {exam.available ? "Ready to attempt" : "Coming soon"}
                      </p>
                    </div>
                    <div className="flex flex-col gap-1.5">
                      {exam.available ? (
                        <>
                          <button onClick={() => navigate(`/quiz/${exam.id}/setup`)}
                            className="px-4 py-2 rounded-xl text-sm font-bold transition-all hover:scale-[1.02]"
                            style={{ background: selectedSubject.gradient, color: "#fff", boxShadow: `0 4px 16px ${selectedSubject.color}44` }}>
                            Start →
                          </button>
                          <button onClick={() => navigate(`/quiz/${exam.id}/leaderboard`)}
                            className="px-3 py-1.5 rounded-xl text-xs font-semibold transition-all hover:scale-[1.02]"
                            style={{ background: "rgba(59,130,246,0.12)", color: "#60a5fa", border: "1px solid rgba(59,130,246,0.3)" }}>
                            🏆 Board
                          </button>
                        </>
                      ) : (
                        <span className="px-3 py-1.5 rounded-full text-xs font-semibold"
                          style={{ background: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))" }}>
                          Soon
                        </span>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Footer */}
      <footer className="w-full text-center py-5 px-4 border-t" style={{ borderColor: "hsl(var(--border))" }}>
        <p className="text-xs mb-2" style={{ color: "hsl(var(--muted-foreground))" }}>For feedbacks or requests:</p>
        <a href="https://instagram.com/syedhamidmukhtar" target="_blank" rel="noopener noreferrer"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold mb-3 transition-all hover:scale-[1.02]"
          style={{ background: "linear-gradient(135deg, #833ab4, #fd1d1d, #fcb045)", color: "#fff" }}>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z"/></svg>
          @syedhamidmukhtar
        </a>
        <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))", opacity: 0.5 }}>Quizzy by Hamid Mukhtar · made for welfare of students.</p>
      </footer>
    </div>
  );
}
